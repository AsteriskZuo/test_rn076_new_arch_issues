// This file is generated automatically. Please do not edit it manually. If necessary, you can run the 'scripts/generate-version.js' script to generate it again.

const VERSION = '2.4.3-beta.1';
export default VERSION;
