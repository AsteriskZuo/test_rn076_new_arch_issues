export const gEventAvatarStatus = 'gEventAvatarStatus';
