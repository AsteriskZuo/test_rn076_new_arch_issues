import { NativeEventEmitter } from 'react-native';
export declare const isTurboModuleEnabled: boolean;
export declare const ChatUikitModuleRN: any;
export declare const eventEmitter: NativeEventEmitter;
export declare function multiply(a: number, b: number): number;
//# sourceMappingURL=index.d.ts.map