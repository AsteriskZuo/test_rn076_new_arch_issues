import { type EmitterSubscription } from 'react-native';
import type { Callback } from '../utils';
export declare const gEventEmitter: import("react-native").DeviceEventEmitterStatic;
export declare function useEventEmitter(): {
    emitEvent: typeof emitEvent;
    addEventListener: typeof addEventListener;
    removeEventListener: typeof removeEventListener;
    removeEventListenerBySub: typeof removeEventListenerBySub;
};
export declare function addEventListener(keyword: string, listener: Callback): EmitterSubscription;
export declare function removeEventListener(keyword: string): void;
export declare function removeEventListenerBySub(keyword: string, sub: EmitterSubscription): void;
export declare function clearEventListener(): void;
export declare function emitEvent(keyword: string, ...params: any[]): void;
//# sourceMappingURL=EventEmitter.d.ts.map