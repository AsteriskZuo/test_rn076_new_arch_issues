import type { AbsoluteViewProps } from './types';
export declare function AbsoluteView(props: AbsoluteViewProps): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=AbsoluteView.d.ts.map