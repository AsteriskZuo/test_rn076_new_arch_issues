import * as React from 'react';
import type { AbsoluteViewContextType } from './types';
/**
 * Context of the AbsoluteView.
 */
export declare const AbsoluteViewContext: React.Context<AbsoluteViewContextType | undefined>;
/**
 * Properties of the AbsoluteView context.
 */
type AbsoluteViewContextProps = React.PropsWithChildren<{}>;
/**
 * The AbsoluteView context's provider.
 */
export declare function AbsoluteViewContextProvider(props: AbsoluteViewContextProps): import("react/jsx-runtime").JSX.Element;
/**
 * Get the AbsoluteView context's value.
 * @returns The AbsoluteView context's value.
 */
export declare function useAbsoluteViewContext(): AbsoluteViewContextType;
export {};
//# sourceMappingURL=AbsoluteViewProvider.d.ts.map