import * as React from 'react';
import type { AlertProps, AlertRef } from './types';
export declare const Alert: React.ForwardRefExoticComponent<AlertProps & React.RefAttributes<AlertRef>>;
//# sourceMappingURL=Alert.d.ts.map