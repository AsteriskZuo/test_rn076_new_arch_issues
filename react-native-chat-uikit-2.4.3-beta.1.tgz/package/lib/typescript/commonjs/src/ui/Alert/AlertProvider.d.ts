import * as React from 'react';
import type { AlertContextType } from './types';
/**
 * Context of the Alert.
 */
export declare const AlertContext: React.Context<AlertContextType | undefined>;
/**
 * Properties of the Alert context.
 */
type AlertContextProps = React.PropsWithChildren<{}>;
/**
 * The Alert context's provider.
 */
export declare function AlertContextProvider(props: AlertContextProps): import("react/jsx-runtime").JSX.Element;
/**
 * Get the Alert context's value.
 * @returns The Alert context's value.
 */
export declare function useAlertContext(): AlertContextType;
export {};
//# sourceMappingURL=AlertProvider.d.ts.map