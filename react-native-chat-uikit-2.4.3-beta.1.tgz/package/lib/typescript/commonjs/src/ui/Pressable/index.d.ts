export * from './PressableHighlight';
//# sourceMappingURL=index.d.ts.map