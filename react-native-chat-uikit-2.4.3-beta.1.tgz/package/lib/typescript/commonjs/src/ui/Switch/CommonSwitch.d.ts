import * as React from 'react';
import { SwitchProps, SwitchRef } from './Switch';
export type CommonSwitchProps = Omit<SwitchProps, 'thumbColor' | 'thumbBackgroundColor' | 'trackColor'>;
export declare const CommonSwitch: React.ForwardRefExoticComponent<CommonSwitchProps & React.RefAttributes<SwitchRef>>;
//# sourceMappingURL=CommonSwitch.d.ts.map