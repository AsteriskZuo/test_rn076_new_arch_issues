import { type ButtonProps } from './Button';
export type BorderButtonProps = Omit<ButtonProps, 'buttonStyle'>;
export declare function BorderButton(props: BorderButtonProps): import("react/jsx-runtime").JSX.Element;
export type BorderIconButtonProps = Omit<BorderButtonProps, 'contentType'>;
export declare function BorderIconButton(props: BorderIconButtonProps): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=BorderButton.d.ts.map