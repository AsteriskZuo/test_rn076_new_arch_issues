import type { ImageStyle, StyleProp } from 'react-native';
export type CheckButtonProps = {
    checked: boolean;
    disable?: boolean;
    onClicked?: () => void;
    style?: StyleProp<ImageStyle>;
};
export declare function CheckButton(props: CheckButtonProps): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=CheckButton.d.ts.map