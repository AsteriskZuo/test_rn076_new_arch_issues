export declare const gMaxRadius = 100;
//# sourceMappingURL=const.d.ts.map