export * from './TriangleView';
//# sourceMappingURL=index.d.ts.map