import { SlideProps } from './types';
export declare const DefaultSlide: (props: SlideProps) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=DefaultSlide.d.ts.map