import { ContextMenuProps } from './types';
export declare function ContextMenu(props: ContextMenuProps): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=ContextMenu.d.ts.map