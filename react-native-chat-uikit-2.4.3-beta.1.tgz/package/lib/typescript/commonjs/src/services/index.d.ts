import type { ClipboardService, ClipboardServiceOption, DirCacheService, DirCacheServiceOption, LocalStorageService, MediaService, MediaServiceOptions } from './types';
/**
 * List of basic services provided.
 */
export declare class Services {
    /**
     * Pasteboard service.
     */
    static cbs: ClipboardService;
    /**
     * Media service.
     */
    static ms: MediaService;
    /**
     * Local storage service.
     */
    static ls: LocalStorageService;
    /**
     * Directory cache service.
     */
    static dcs: DirCacheService;
    /**
     * Create clipboard service single object.
     * @param option - The option. see {@link ClipboardServiceOption}
     * @returns The clipboard service object.
     */
    static createClipboardService(option: ClipboardServiceOption): ClipboardService;
    /**
     * Create media service single object.
     * @param option - The option. see {@link MediaServiceOptions}
     * @returns The media service object.
     */
    static createMediaService(option: MediaServiceOptions): MediaService;
    /**
     * Create local storage service single object.
     * @param option - The option. see {@link LocalStorageService}
     * @returns The local storage service object.
     */
    static createLocalStorageService(service?: LocalStorageService): LocalStorageService;
    /**
     * Create directory cache service single object.
     * @param option - The option. see {@link DirCacheServiceOption}
     * @returns The directory cache service object.
     */
    static createDirCacheService(option: DirCacheServiceOption): DirCacheService;
}
export * from './types';
//# sourceMappingURL=index.d.ts.map