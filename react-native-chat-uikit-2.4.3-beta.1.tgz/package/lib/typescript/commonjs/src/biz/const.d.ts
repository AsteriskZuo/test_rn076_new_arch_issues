export declare const gBottomSheetHeaderHeight = 17;
export declare const gGroupListPageNumber = 20;
export declare const gVoiceBarHeight = 200;
export declare const gMaxVoiceDuration = 60000;
export declare const gMinVoiceDuration = 1000;
export declare const g_index_alphabet_range = "ABCDEFGHIJKLMNOPQRSTUVWXYZ#";
export declare const g_index_alphabet_range_array: string[];
export declare const gReportMessageList: {
    key: string;
    value: string;
}[];
//# sourceMappingURL=const.d.ts.map