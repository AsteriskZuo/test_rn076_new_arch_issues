import * as React from 'react';
export declare const BottomVoiceBar: React.ForwardRefExoticComponent<import("../types").PropsWithError & import("../types").PropsWithTest & {
    height?: number;
    onClickedRecordButton?: (state: import("./types").VoiceBarState) => void;
    onClickedClearButton?: () => void;
    onClickedSendButton?: (voice: import("../ConversationDetail").SendVoiceProps) => void;
    onFailed?: (error: {
        reason: string;
        error: any;
    }) => void;
    onState?: (state: import("./types").VoiceBarState) => void;
} & Pick<import("../..").SlideModalProps, "onRequestModalClose"> & React.RefAttributes<import("../..").ModalRef>>;
//# sourceMappingURL=BottomVoiceBar.d.ts.map