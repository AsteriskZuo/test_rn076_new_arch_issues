import { MessageMenuHeaderProps } from '../types';
export declare function BottomSheetMenuHeader(props: MessageMenuHeaderProps): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=BottomSheetMenuHeader.d.ts.map