export declare const MESSAGE_CONTEXT_NAME_MENU_MAX_WIDTH: number;
//# sourceMappingURL=MessageContextNameMenu.const.d.ts.map