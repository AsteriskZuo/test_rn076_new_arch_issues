import * as React from 'react';
export type useMessagePinProps = {};
export declare function useMessagePin(props: useMessagePinProps): {
    maxListHeight: number;
    setMaxListHeight: React.Dispatch<React.SetStateAction<number>>;
    panHandlers: import("react-native").GestureResponderHandlers;
    msgPinPlaceHolderHeightRef: React.MutableRefObject<number>;
    msgPinPlaceHolderHeightAnimate: (toValue: number, onFinished?: (result: import("react-native").Animated.EndResult) => void, offsetToZero?: boolean) => void;
    msgPinPlaceHolderCurrentHeight: import("react-native").Animated.Value;
    msgListMaxCurrentHeight: import("react-native").Animated.AnimatedInterpolation<string | number>;
    msgPinHeightRef: React.MutableRefObject<number>;
    msgPinHeightAnimate: (toValue: number, onFinished?: (result: import("react-native").Animated.EndResult) => void, offsetToZero?: boolean) => void;
    msgPinCurrentHeight: import("react-native").Animated.Value;
    msgPinLabelTranslateYRef: React.MutableRefObject<number>;
    msgPinLabelTranslateYAnimate: (toValue: number, onFinished?: (result: import("react-native").Animated.EndResult) => void, offsetToZero?: boolean) => void;
    msgPinLabelCurrentTranslateY: import("react-native").Animated.Value;
    msgPinBackgroundOpacityAnimate: (toValue: number, onFinished?: (result: import("react-native").Animated.EndResult) => void, offsetToZero?: boolean) => void;
    msgPinBackgroundCurrentOpacity: import("react-native").Animated.Value;
};
//# sourceMappingURL=MessagePin.hooks.d.ts.map