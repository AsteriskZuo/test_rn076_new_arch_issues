import type { MessageHistoryListProps } from './types';
export declare function MessageHistoryList(props: MessageHistoryListProps): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MessageHistoryList.d.ts.map