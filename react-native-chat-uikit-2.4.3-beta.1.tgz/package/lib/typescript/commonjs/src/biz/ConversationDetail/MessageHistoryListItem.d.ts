import * as React from 'react';
import { ChatMessage } from '../../rename.chat';
import type { MessageHistoryListItemProps } from './types';
export declare function MessageHistoryListItem(props: MessageHistoryListItemProps): import("react/jsx-runtime").JSX.Element;
export type MessageHistoryImageProps = {
    msg: ChatMessage;
    maxWidth?: number;
};
export declare function MessageHistoryImage(props: MessageHistoryImageProps): import("react/jsx-runtime").JSX.Element;
export type MessageHistoryVideoProps = {
    msg: ChatMessage;
    maxWidth?: number;
};
export declare function MessageHistoryVideo(props: MessageHistoryVideoProps): import("react/jsx-runtime").JSX.Element;
export declare const MessageHistoryListItemMemo: React.MemoExoticComponent<typeof MessageHistoryListItem>;
//# sourceMappingURL=MessageHistoryListItem.d.ts.map