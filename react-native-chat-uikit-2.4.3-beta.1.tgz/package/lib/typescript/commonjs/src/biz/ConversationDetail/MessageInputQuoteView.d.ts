import { ChatMessage } from '../../rename.chat';
/**
 * Message Input Quote View Component properties.
 */
export type MessageInputQuoteViewProps = {
    showQuote: boolean;
    onDel: () => void;
    msg?: ChatMessage;
};
/**
 * Message Input Quote View Component.
 */
export declare const MessageInputQuoteView: (props: MessageInputQuoteViewProps) => import("react/jsx-runtime").JSX.Element | null;
//# sourceMappingURL=MessageInputQuoteView.d.ts.map