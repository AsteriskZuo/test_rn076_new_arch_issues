import type { ConversationDetailProps } from './types';
/**
 * Conversation Detail Component.
 *
 * This component displays the chat content of individual chats and group chats. This component mainly includes a message bubble list component and a message sending component, as well as a bottom menu component and a warning component.
 */
export declare function ConversationDetail(props: ConversationDetailProps): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=ConversationDetail.d.ts.map