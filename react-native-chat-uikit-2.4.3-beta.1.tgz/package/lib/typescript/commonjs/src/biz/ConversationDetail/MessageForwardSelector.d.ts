import * as React from 'react';
import { ContactModel, GroupModel } from '../../chat';
import type { ChatMessage } from '../../rename.chat';
import { ContactListProps } from '../ContactList';
import { GroupListProps } from '../GroupList';
import type { PropsWithBack, PropsWithNavigationBar, PropsWithRef } from '../types';
export type SelectContactListProps = Pick<ContactListProps, 'containerStyle' | 'onClickedSearch' | 'selectedData'> & {
    index: number;
    currentIndex: number;
    selectedMsgs?: ChatMessage[];
};
export declare function SelectContactList(props: SelectContactListProps): import("react/jsx-runtime").JSX.Element;
export type SelectGroupListProps = Pick<GroupListProps, 'containerStyle'> & {
    index: number;
    currentIndex: number;
    selectedMsgs?: ChatMessage[];
};
export declare function SelectGroupList(props: SelectGroupListProps): import("react/jsx-runtime").JSX.Element;
export type MessageForwardSelectorRef = {
    forwardMessage: (data: ContactModel | GroupModel) => void;
};
export type MessageForwardSelectorProps = PropsWithNavigationBar & PropsWithBack & PropsWithRef<MessageForwardSelectorRef> & {
    onClickedSearch?: (data?: any) => void;
    selectedData?: ContactModel[];
    selectedMsgs?: ChatMessage[];
    propsRef?: React.MutableRefObject<MessageForwardSelectorRef>;
};
export declare function MessageForwardSelector(props: MessageForwardSelectorProps): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MessageForwardSelector.d.ts.map