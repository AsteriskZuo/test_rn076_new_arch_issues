export declare const gRequestMaxMessageCount = 30;
export declare const gRequestMaxThreadCount = 30;
export declare const gTriangleWidth = 5;
export declare const gMessageAvatarSize = 28;
export declare const gMsgPinHeight = 54;
//# sourceMappingURL=const.d.ts.map