import type { ListIndexProps } from './types';
/**
 * List Index Component.
 *
 * This component is mainly used with alphabetical lists.
 */
export declare const ListIndex: (props: ListIndexProps) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=ListIndex.d.ts.map