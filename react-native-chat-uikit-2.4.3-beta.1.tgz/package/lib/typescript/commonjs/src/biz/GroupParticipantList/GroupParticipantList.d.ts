import type { GroupParticipantListProps } from './types';
/**
 * Group Participant List Component.
 */
export declare function GroupParticipantList(props: GroupParticipantListProps): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=GroupParticipantList.d.ts.map