import * as React from 'react';
import type { GroupParticipantListItemProps } from './types';
/**
 * Group Participant List Item Component.
 */
export declare function GroupParticipantListItem(props: GroupParticipantListItemProps): import("react/jsx-runtime").JSX.Element;
export declare const GroupParticipantListItemMemo: React.MemoExoticComponent<typeof GroupParticipantListItem>;
//# sourceMappingURL=GroupParticipantList.item.d.ts.map