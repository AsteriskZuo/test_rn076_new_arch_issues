import * as React from 'react';
import { DataModel } from '../../chat';
import type { ChatMessageReaction } from '../../rename.chat';
import { SlideModalRef } from '../../ui/Modal';
export type MessageReactionModel = Omit<ChatMessageReaction, 'userList'> & {
    userList: DataModel[];
};
/**
 * Referencing Values of the `BottomSheetReactionDetail` component.
 */
export type BottomSheetReactionDetailRef = SlideModalRef & {
    /**
     * While displaying the component, the menu items will also be dynamically changed.
     */
    startShowWithProps: (props: BottomSheetReactionDetailProps) => void;
};
export type BottomSheetReactionDetailProps = {
    /**
     * To request to close the component, you usually need to call the `startHide` method here.
     */
    onRequestModalClose: () => void;
    /**
     * The maximum height of the component.
     *
     * @default half of the entire screen.
     */
    maxHeight?: number;
    /**
     * The current selected reaction.
     */
    currentSelected?: string;
    /**
     * The reaction list.
     */
    reactionList: MessageReactionModel[];
    /**
     * The message ID.
     */
    msgId: string;
};
/**
 * The `BottomSheetReactionDetail` component displays the list of reactions and the list of users who have reacted to the message.
 */
export declare const BottomSheetReactionDetail: React.ForwardRefExoticComponent<BottomSheetReactionDetailProps & React.RefAttributes<BottomSheetReactionDetailRef>>;
//# sourceMappingURL=BottomSheetReactionDetail.d.ts.map