import * as React from 'react';
import { StyleProp, ViewStyle } from 'react-native';
import { StatusType } from '../types';
type Point = {
    x: number;
    y: number;
};
export declare function findIntersectionPoints(parentSize: number): Point[];
export type AvatarStatusProps = {
    parentSize: number;
    size?: number;
    childrenPaddingSize: number;
    scale: number;
    intersection?: Point;
    positionStyle?: 'bottomRight1' | 'bottomRight2';
    containerStyle?: StyleProp<ViewStyle>;
    style?: StyleProp<ViewStyle>;
    status: string;
    AvatarStatusRender?: React.FC<{
        status: StatusType;
        style?: StyleProp<ViewStyle>;
    }> | React.MemoExoticComponent<(props: {
        status: StatusType;
        style?: StyleProp<ViewStyle>;
    }) => JSX.Element>;
};
export declare function AvatarStatus(props: AvatarStatusProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=AvatarStatus.d.ts.map