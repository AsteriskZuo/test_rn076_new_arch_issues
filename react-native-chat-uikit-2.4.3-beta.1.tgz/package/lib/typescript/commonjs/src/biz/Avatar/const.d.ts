export declare const gEventAvatarStatus = "gEventAvatarStatus";
//# sourceMappingURL=const.d.ts.map