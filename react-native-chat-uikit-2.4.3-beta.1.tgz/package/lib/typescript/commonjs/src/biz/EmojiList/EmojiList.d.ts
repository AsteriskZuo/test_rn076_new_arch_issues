import * as React from 'react';
import { StyleProp, ViewStyle } from 'react-native';
import type { EmojiIconItem } from '../types';
/**
 * Emoji List Component properties.
 */
export type EmojiListProps = {
    /**
     * Callback function when an emoji is selected.
     */
    onFace?: (id: string) => void;
    /**
     * Callback function when the delete button is clicked.
     */
    onDel?: () => void;
    /**
     * Callback function when the send button is clicked.
     */
    onSend?: () => void;
    /**
     * The style of the container.
     */
    containerStyle?: StyleProp<ViewStyle>;
    /**
     * The number of emojis per row.
     */
    countPerRow?: number;
    /**
     * The list of emoji expressions.
     *
     * The format needs to be followed. For example: `U+1F641` {@link FACE_ASSETS}. It will replace the built-in emoji  list.
     */
    emojiList?: EmojiIconItem[];
    /**
     * Whether to use the emoji chat mode.
     *
     * Its setting will affect the type of the return value of `onFace`. If true, returns the emoji string, otherwise returns the `U+xxxxx` string.
     *
     * @default false
     */
    isEmojiCharacter?: boolean;
};
/**
 * List of emoji expressions.
 *
 * @param props {@link EmojiListProps}
 * @returns JSX.Element
 */
export declare function EmojiList(props: EmojiListProps): import("react/jsx-runtime").JSX.Element;
export declare const EmojiListMemo: React.MemoExoticComponent<typeof EmojiList>;
//# sourceMappingURL=EmojiList.d.ts.map