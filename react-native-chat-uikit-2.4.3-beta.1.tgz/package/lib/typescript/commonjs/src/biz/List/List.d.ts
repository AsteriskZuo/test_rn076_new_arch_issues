export declare function XXXList(): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=List.d.ts.map