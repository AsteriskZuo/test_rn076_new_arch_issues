import type { DefaultComponentModel, ListSearchProps } from './types';
export declare function ListSearch<ComponentModel extends DefaultComponentModel = DefaultComponentModel>(props: ListSearchProps<ComponentModel>): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=ListSearch.d.ts.map