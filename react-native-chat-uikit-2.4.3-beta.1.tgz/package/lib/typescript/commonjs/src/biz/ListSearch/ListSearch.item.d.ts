import type { DataModel } from '../../chat';
import type { ContactSearchModel } from '../ContactList';
import type { ListSearchItemProps } from './types';
export declare function ListSearchItem<ComponentModel extends DataModel = DataModel>(props: ListSearchItemProps<ComponentModel>): import("react/jsx-runtime").JSX.Element;
export declare function DefaultListSearchItem<ComponentModel extends DataModel = DataModel>(props: ListSearchItemProps<ComponentModel>): import("react/jsx-runtime").JSX.Element;
export declare function StateListSearchItem(props: ListSearchItemProps<ContactSearchModel>): import("react/jsx-runtime").JSX.Element;
export declare function ForwardListSearchItem(props: ListSearchItemProps<ContactSearchModel>): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=ListSearch.item.d.ts.map