import * as React from 'react';
import type { GroupListItemProps } from './types';
/**
 * Group List Item Component.
 */
export declare function GroupListItem(props: GroupListItemProps): import("react/jsx-runtime").JSX.Element;
export declare const GroupListItemMemo: React.MemoExoticComponent<typeof GroupListItem>;
//# sourceMappingURL=GroupList.item.d.ts.map