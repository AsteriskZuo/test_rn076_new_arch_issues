import type { GroupListProps } from './types';
/**
 * Group List Component.
 */
export declare function GroupList(props: GroupListProps): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=GroupList.d.ts.map