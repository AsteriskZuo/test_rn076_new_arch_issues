import type { ContactListNavigationBarProps } from './types';
type _ContactListNavigationBarProps = ContactListNavigationBarProps & {
    userId?: string;
    selectedCount?: number;
    selectedMemberCount?: number;
    avatarUrl?: string;
    onClickedAddGroupParticipant?: () => void;
    onClickedCreateGroup?: () => void;
    onClickedAvatar?: () => void;
};
export declare const ContactListNavigationBar: (props: _ContactListNavigationBarProps) => import("react/jsx-runtime").JSX.Element | null;
export {};
//# sourceMappingURL=ContactList.navi.d.ts.map