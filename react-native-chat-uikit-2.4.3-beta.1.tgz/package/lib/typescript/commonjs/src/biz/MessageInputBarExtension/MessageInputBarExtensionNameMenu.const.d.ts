export declare const MESSAGE_INPUT_BAR_EXTENSION_NAME_MENU_HEIGHT = 220;
export declare const MESSAGE_INPUT_BAR_EXTENSION_NAME_MENU_HEIGHT_HALF = 132;
//# sourceMappingURL=MessageInputBarExtensionNameMenu.const.d.ts.map