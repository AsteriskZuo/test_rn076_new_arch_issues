import type { BlockListProps } from './types';
/**
 * The block list component mainly consists of four parts, including navigation component, search style component, individual list item component, and list component. Supports displaying bottom menu components and warning components. The navigation bar component can be set to display or not, customize the style, or even replace it as a whole. The search style component supports whether to display, and the individual list item component supports whether to display, add or replace any multiple components. List components support more property settings.
 */
export declare function BlockList(props: BlockListProps): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=BlockList.d.ts.map