import type { EditInfoProps } from './types';
/**
 * Edit Info Component.
 */
export declare function EditInfo(props: EditInfoProps): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=EditInfo.d.ts.map