import * as React from 'react';
import type { ContactInfoRef } from './types';
/**
 * Contact Info Component.
 *
 * If it is a contact, the send button is displayed, if it is not a contact, the add contact button is displayed. If it is the current user, there are no operation options.
 */
export declare const ContactInfo: React.ForwardRefExoticComponent<import("../types").PropsWithBack & import("../types").PropsWithNavigationBar & {
    onClickedNavigationBarButton?: () => void;
    hasSendMessage?: boolean;
    hasAudioCall?: boolean;
    hasVideoCall?: boolean;
    onClearChat?: () => void;
    doNotDisturb?: boolean;
    onDoNotDisturb?: (isDisturb: boolean) => void;
    blockUser?: boolean;
    onBlockUser?: (isBlock: boolean) => void;
    containerStyle?: import("react-native").StyleProp<import("react-native").ViewStyle>;
    onSendMessage?: (id: string) => void;
    onAudioCall?: (id: string) => void;
    onVideoCall?: (id: string) => void;
    onSearch?: (id: string) => void;
    onCopyId?: (id: string) => void;
    onInitMenu?: (initItems: import("../types").InitMenuItemsType[]) => import("../types").InitMenuItemsType[];
    onInitButton?: (initButtons: React.ReactElement<import("../..").BlockButtonProps>[]) => React.ReactElement<import("../..").BlockButtonProps>[];
} & {
    userId: string;
    userName?: string;
    userAvatar?: string;
    isContact?: boolean;
    onAddContact?: (id: string) => void;
    onRequestData?: (id: string) => import("../..").ContactModel | Promise<import("../..").ContactModel> | undefined;
} & {
    onClickedContactRemark?: (userId: string, remark?: string) => void;
    customItemRender?: (def: React.ReactNode[]) => React.ReactNode[];
} & React.RefAttributes<ContactInfoRef>>;
//# sourceMappingURL=ContactInfo.d.ts.map