import type { CreateGroupProps } from './types';
/**
 * Create Group Component.
 */
export declare function CreateGroup(props: CreateGroupProps): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=CreateGroup.d.ts.map