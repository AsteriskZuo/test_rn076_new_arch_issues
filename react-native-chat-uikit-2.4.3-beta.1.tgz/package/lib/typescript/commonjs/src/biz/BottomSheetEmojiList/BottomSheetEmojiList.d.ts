import * as React from 'react';
import { SlideModalRef } from '../../ui/Modal';
import type { EmojiIconItem } from '../types';
/**
 * Referencing Values of the `BottomSheetEmojiList` component.
 */
export type BottomSheetEmojiListRef = SlideModalRef & {
    /**
     * While displaying the component, the menu items will also be dynamically changed.
     */
    startShowWithProps: (props: BottomSheetEmojiListProps) => void;
};
/**
 * Properties of the `BottomSheetEmojiList` component.
 */
export type BottomSheetEmojiListProps = {
    /**
     * To request to close the component, you usually need to call the `startHide` method here.
     */
    onRequestModalClose: () => void;
    /**
     * emoji list.
     */
    emojiList: EmojiIconItem[];
    /**
     * The maximum height of the component.
     *
     * @default half of the entire screen.
     */
    maxHeight?: number;
    /**
     * Callback function when an emoji is selected.
     */
    onFace?: (face: string) => void;
};
/**
 * The BottomSheetEmojiList component provides menu functionality.
 */
export declare const BottomSheetEmojiList: React.ForwardRefExoticComponent<BottomSheetEmojiListProps & React.RefAttributes<BottomSheetEmojiListRef>>;
//# sourceMappingURL=BottomSheetEmojiList.d.ts.map