/**
 * Navigation bar back button style.
 * @returns JSX.Element
 */
export declare function BackButton(): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=Back.d.ts.map