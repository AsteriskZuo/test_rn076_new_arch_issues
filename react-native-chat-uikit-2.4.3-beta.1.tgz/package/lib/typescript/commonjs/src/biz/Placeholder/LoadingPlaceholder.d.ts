/**
 * The data is not ready for loading placeholder component.
 * @returns JSX.Element
 */
export declare function LoadingPlaceholder(): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=LoadingPlaceholder.d.ts.map