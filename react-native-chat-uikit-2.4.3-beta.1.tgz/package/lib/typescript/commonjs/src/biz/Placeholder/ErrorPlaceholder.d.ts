/**
 * Placeholder component after error. You can click the retry button
 * @param param0 The callback function when the button is clicked.
 * @returns JSX.Element
 */
export declare function ErrorPlaceholder({ onClicked }: {
    onClicked: () => void;
}): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=ErrorPlaceholder.d.ts.map