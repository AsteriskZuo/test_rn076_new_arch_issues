/**
 * Blank placeholder component.
 * @returns JSX.Element
 */
export declare function EmptyPlaceholder(): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=EmptyPlaceholder.d.ts.map