import type { EmitterSubscription } from 'react-native';
import type { DataModel, DataModelType } from './types';
/**
 * Data Profile Provider.
 */
export declare class DataProfileProvider {
    _dataList: Map<string, DataModel>;
    private _userProfile?;
    private _groupProfile?;
    constructor();
    /**
     * Convert data to map.
     * @param data
     * @returns
     */
    static toMap(data: DataModel[]): Map<string, DataModel>;
    /**
     * Convert map to array.
     */
    static toArray(data: Map<string, DataModel>): DataModel[];
    /**
     * Register user profile.
     */
    registerUserProfile(h?: ((data: Map<string, DataModel>) => Map<string, DataModel>) | ((data: Map<string, DataModel>) => Promise<Map<string, DataModel>>)): void;
    /**
     * Register group profile.
     */
    registerGroupProfile(h?: ((data: Map<string, DataModel>) => Map<string, DataModel>) | ((data: Map<string, DataModel>) => Promise<Map<string, DataModel>>)): void;
    /**
     * Clear data list.
     */
    clearDataList(): void;
    /**
     * Get a list of data.
     * @param list The data list. Typically comes from a component data source.
     * @returns List of cached data.
     */
    getDataList(list: DataModel[]): DataModel[];
    /**
     * Get data by id.
     */
    getDataById(id: string): DataModel | undefined;
    /**
     * Get a list of users.
     */
    getUserList(ids: string[]): DataModel[];
    /**
     * Get a list of groups.
     */
    getGroupList(ids: string[]): DataModel[];
    /**
     * Update the cache and notify interested components.
     *
     * Data that has been requested and received will no longer trigger notifications.
     *
     * @param dataList The default value can be obtained through the `getDataList` method.
     * @param isUpdateNotExisted Whether the non-existing data also needs to be updated. Default is false.
     * @param disableDispatch Whether to disable notification. Default is false.
     * @param dispatchHandler Callback for dispatching notifications. If false is returned, it is not distributed internally.
     */
    updateDataList(params: {
        dataList: Map<string, DataModel>;
        isUpdateNotExisted?: boolean;
        disableDispatch?: boolean;
        dispatchHandler?: (data: Map<string, DataModel>) => boolean;
    }): void;
    /**
     * Request updated data and notify interested components. The registered callback `registerUserProfile` and `registerGroupProfile` will be used to request data.
     *
     * Data that has been requested and received will no longer trigger notifications.
     *
     * @params dataList The data list to be updated.
     * - dataList: The data list to be updated.
     * - isUpdateNotExisted: Whether the non-existing data also needs to be updated. Default is false.
     * - disableDispatch: Whether to disable notification. Default is false.
     * - requestHasData: Whether to request data that already exists. Default is true.
     * - dispatchHandler: Callback for dispatching notifications. If false is returned, it is not distributed internally.
     */
    requestDataList(params: {
        dataList: Map<string, DataModelType>;
        isUpdateNotExisted?: boolean;
        disableDispatch?: boolean;
        requestHasData?: boolean;
        dispatchHandler?: (data: Map<string, DataModel>) => boolean;
    }): Promise<void>;
    /**
     * Notify the component of interest.
     *
     * Follow notifications via `setObserver`.
     *
     * @param updateList Changed list.
     */
    dispatch(updateList: Map<string, DataModel>): void;
    /**
     * Add an observer.
     */
    addObserver(observer: (updateList: Map<string, DataModel>) => void): EmitterSubscription;
    /**
     * Remove the observer by subscription.
     */
    removeObserver(sub: EmitterSubscription): void;
    /**
     * Clear the observer.
     */
    clearObserver(): void;
}
export declare function useDataProfileProvider(): {
    emitEvent: typeof import("..").emitEvent;
    addDataProfileListener: (listener: (updateList: Map<string, DataModel>) => void) => EmitterSubscription;
    removeDataProfileListener: (sub: EmitterSubscription) => void;
};
//# sourceMappingURL=DataProfileProvider.d.ts.map