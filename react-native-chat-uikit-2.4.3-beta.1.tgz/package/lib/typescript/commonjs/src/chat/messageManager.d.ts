import { ChatConversationType, ChatGroupMessageAck, ChatMessage, ChatMessageChatType, ChatMessagePinInfo, ChatRecalledMessageInfo, ChatSearchDirection } from '../rename.chat';
import type { MessageCacheManager, MessageManagerListener } from './messageManager.types';
import type { ChatService, ChatServiceListener } from './types';
import type { ConversationModel } from './types.ui';
/**
 * Message Cache Manager Implementation.
 */
export declare class MessageCacheManagerImpl implements MessageCacheManager {
    _client: ChatService;
    _listener?: ChatServiceListener;
    _userListener: Map<string, MessageManagerListener>;
    _sendList: Map<string, {
        msg: ChatMessage;
    }>;
    _downloadList: Map<string, {
        msg: ChatMessage;
    }>;
    _recallTimeout: number;
    constructor(client: ChatService);
    init(): void;
    unInit(): void;
    reset(): void;
    addListener(key: string, listener: MessageManagerListener): void;
    removeListener(key: string): void;
    emitSendMessageChanged(msg: ChatMessage): void;
    emitSendMessageProgressChanged(msg: ChatMessage): void;
    emitSendMessageBefore(msg: ChatMessage): void;
    emitRecallMessageBefore(msg: ChatMessage): void;
    emitRecallMessageChanged(params: {
        isOk: boolean;
        orgMsg?: ChatMessage;
        tipMsg?: ChatMessage;
    }): void;
    emitRecvMessageStateChanged(msg: ChatMessage): void;
    emitAttachmentChanged(msg: ChatMessage): void;
    emitAttachmentProgressChanged(msg: ChatMessage): void;
    emitConversationUnreadCountChanged(): void;
    emitTipMessage(msg: ChatMessage): void;
    bindOnMessagesReceived(messages: Array<ChatMessage>): void;
    bindOnMessagesRead(messages: Array<ChatMessage>): void;
    bindOnGroupMessageRead(_groupMessageAcks: Array<ChatGroupMessageAck>): void;
    bindOnMessagesDelivered(messages: Array<ChatMessage>): void;
    onMessagesRecalledInfo(messages: Array<ChatRecalledMessageInfo>): void;
    bindOnMessageContentChanged(message: ChatMessage, lastModifyOperatorId: string, _lastModifyTime: number): void;
    bindOnMessagePinChanged(params: {
        messageId: string;
        convId: string;
        pinOperation: number;
        pinInfo: ChatMessagePinInfo;
    }): void;
    setCurrentConv(conv?: ConversationModel): void;
    getCurrentConv(): ConversationModel | undefined;
    sendMessageReadAck(params: {
        message: ChatMessage;
    }): void;
    setMessageRead(params: {
        convId: string;
        convType: ChatConversationType;
        message: ChatMessage;
    }): void;
    sendMessage(msg: ChatMessage): Promise<void>;
    resendMessage(msg: ChatMessage): Promise<void>;
    createRecallMessageTip(msg: ChatMessage): ChatMessage;
    recallMessage(msg: ChatMessage): Promise<void>;
    downloadAttachment(msg: ChatMessage): Promise<void>;
    downloadAttachmentForThread(msg: ChatMessage): Promise<void>;
    loadHistoryMessage(params: {
        convId: string;
        convType: ChatConversationType;
        startMsgId: string;
        loadCount: number;
        direction?: ChatSearchDirection;
        isChatThread?: boolean;
    }): Promise<ChatMessage[]>;
    setRecallMessageTimeout(recallTimeout?: number): void;
    parseUrlPreview(msg: ChatMessage, isForce: boolean, onResult: (msg: ChatMessage) => void): void;
    addTipMessage(params: {
        convId: string;
        convType: ChatMessageChatType;
        tipType: string;
        kvs: Record<string, string>;
        isChatThread?: boolean;
        onResult?: (isOk: boolean) => void;
    }): void;
}
//# sourceMappingURL=messageManager.d.ts.map