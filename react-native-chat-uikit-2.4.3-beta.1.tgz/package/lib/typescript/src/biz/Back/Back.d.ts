/// <reference types="react" />
/**
 * Navigation bar back button style.
 * @returns JSX.Element
 */
export declare function BackButton(): JSX.Element;
//# sourceMappingURL=Back.d.ts.map