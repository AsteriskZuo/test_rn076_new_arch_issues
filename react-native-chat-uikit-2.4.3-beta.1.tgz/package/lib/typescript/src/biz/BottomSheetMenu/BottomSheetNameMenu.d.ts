import * as React from 'react';
import { InitMenuItemsType } from '../types';
import { ContextNameMenuRef } from '../types';
/**
 * The BottomSheetNameMenu component provides menu functionality.
 *
 * Compared with `BottomSheetMenu`, it is simpler to use, you only need to enter a text array.
 *
 * @example
 * ```tsx
 * const menuRef = React.useRef<ContextNameMenuRef>({} as any);
 * // ...
 * <BottomSheetNameMenu
 *   ref={menuRef}
 *   initItems={[]}
 *   onRequestModalClose={() => {
 *     menuRef?.current?.startHide?.();
 *   }}
 * />
 * // ...
 * menuRef?.current?.startShowWithInit([
 *   {
 *     name: 'Mute',
 *     isHigh: false,
 *     onClicked: () => {
 *       if (userId !== im.userId) {
 *         muteMember(userId, true);
 *       }
 *       menuRef?.current?.startHide?.();
 *     },
 *   },
 *   {
 *     name: 'Remove',
 *     isHigh: true,
 *     onClicked: () => {
 *       if (userId !== im.userId) {
 *         removeMember(userId);
 *       }
 *       menuRef?.current?.startHide?.();
 *     },
 *   },
 * ]);
 * ```
 */
export declare const BottomSheetNameMenu: React.ForwardRefExoticComponent<Omit<import("../types").BizContextMenuProps, "initItems"> & {
    initItems?: InitMenuItemsType[];
    layoutType?: "center" | "left";
    hasCancel?: boolean;
    suggestedPosition?: {
        x: number;
        y: number;
    };
    noCoverageArea?: import("../..").ComponentArea;
    maxRowCount?: number;
    unitCountPerRow?: number;
    emojiListPosition?: "bottom" | "top";
} & React.RefAttributes<ContextNameMenuRef>>;
//# sourceMappingURL=BottomSheetNameMenu.d.ts.map