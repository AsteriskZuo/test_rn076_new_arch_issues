/// <reference types="react" />
import { MessageMenuHeaderProps } from '../types';
export declare function BottomSheetMenuHeader(props: MessageMenuHeaderProps): JSX.Element;
//# sourceMappingURL=BottomSheetMenuHeader.d.ts.map