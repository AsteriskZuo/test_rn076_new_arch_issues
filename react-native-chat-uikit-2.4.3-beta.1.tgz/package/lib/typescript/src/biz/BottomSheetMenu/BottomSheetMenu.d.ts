import * as React from 'react';
import { BizContextMenuRef } from '../types';
/**
 * The BottomSheetMenu component provides menu functionality.
 *
 * @example
 *
 * ```tsx
 * const ref = React.useRef<BizContextMenuRef>({} as any);
 * // ...
 *  <BottomSheetMenu
 *   ref={ref}
 *   onRequestModalClose={() => {
 *     ref.current.startHide();
 *   }}
 *   title={
 *     'Nickname: Sei la cosa più bella che mia sia mai capitato non so stare senza te.'
 *   }
 *   initItems={data}
 * />
 * ```
 */
export declare const BottomSheetMenu: React.ForwardRefExoticComponent<import("../types").ContextBaseMenuProps & {
    initItems?: React.ReactElement<any, string | React.JSXElementConstructor<any>>[];
    maxHeight?: number;
} & React.RefAttributes<BizContextMenuRef>>;
//# sourceMappingURL=BottomSheetMenu.d.ts.map