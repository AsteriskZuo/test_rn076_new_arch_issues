import * as React from 'react';
export declare const BottomVoiceBar: React.ForwardRefExoticComponent<import("../types").PropsWithError & import("../types").PropsWithTest & {
    height?: number;
    onClickedRecordButton?: (state: import("./types").VoiceBarState) => void;
    onClickedClearButton?: () => void;
    onClickedSendButton?: (voice: import("../ConversationDetail").SendVoiceProps) => void;
    onFailed?: (error: {
        reason: string;
        error: any;
    }) => void;
    onState?: (state: import("./types").VoiceBarState) => void;
} & Pick<import("../../ui/Modal").SlideModalProps, "onRequestModalClose"> & React.RefAttributes<import("../../ui/Modal").ModalRef>>;
//# sourceMappingURL=BottomVoiceBar.d.ts.map