/// <reference types="react" />
import type { MessageSearchProps } from './types';
export declare function MessageSearch(props: MessageSearchProps): JSX.Element;
//# sourceMappingURL=MessageSearch.d.ts.map