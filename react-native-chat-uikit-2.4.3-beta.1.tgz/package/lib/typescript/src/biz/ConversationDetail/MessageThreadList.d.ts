import * as React from 'react';
import type { MessageThreadListRef } from './types';
/**
 * Message Thread List Component.
 */
export declare const MessageThreadList: React.ForwardRefExoticComponent<import("../types").PropsWithError & import("../types").PropsWithTest & import("../types").PropsWithNavigationBar & import("../types").PropsWithBack<any> & {
    containerStyle?: import("react-native").StyleProp<import("react-native").ViewStyle>;
    parentId: string;
    onClickedItem?: (model: import("./types").MessageThreadModel) => boolean | void;
} & React.RefAttributes<MessageThreadListRef>>;
export declare const MessageThreadListMemo: React.MemoExoticComponent<React.ForwardRefExoticComponent<import("../types").PropsWithError & import("../types").PropsWithTest & import("../types").PropsWithNavigationBar & import("../types").PropsWithBack<any> & {
    containerStyle?: import("react-native").StyleProp<import("react-native").ViewStyle>;
    parentId: string;
    onClickedItem?: (model: import("./types").MessageThreadModel) => boolean | void;
} & React.RefAttributes<MessageThreadListRef>>>;
//# sourceMappingURL=MessageThreadList.d.ts.map