/// <reference types="react" />
/// <reference types="react" />
import { TopNavigationBarElementType } from '../TopNavigationBar';
import type { ConversationDetailModelType, ConversationSelectModeType } from './types';
type _ConversationDetailNavigationBarProps<LeftProps, RightProps> = {
    convId: string;
    convType: number;
    convName?: string;
    convAvatar?: string;
    type: ConversationDetailModelType;
    selectMode?: ConversationSelectModeType;
    onBack?: (data?: any) => void;
    onClickedAvatar?: () => void;
    NavigationBar?: TopNavigationBarElementType<LeftProps, RightProps>;
    doNotDisturb?: boolean;
    newThreadName?: string;
    onClickedThread?: () => void;
    onClickedVoice?: () => void;
    onClickedVideo?: () => void;
    onClickedAV?: () => void;
    onClickedPinMessage?: () => void;
    onClickedThreadMore?: () => void;
    onCancelMultiSelected?: () => void;
    parentName?: string;
    messageTyping?: boolean;
};
export declare const ConversationDetailNavigationBar: <LeftProps, RightProps>(props: _ConversationDetailNavigationBarProps<LeftProps, RightProps>) => JSX.Element;
export {};
//# sourceMappingURL=ConversationDetail.navi.d.ts.map