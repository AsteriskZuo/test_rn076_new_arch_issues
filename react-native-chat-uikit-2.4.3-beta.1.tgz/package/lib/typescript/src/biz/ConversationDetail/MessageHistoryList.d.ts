/// <reference types="react" />
import type { MessageHistoryListProps } from './types';
export declare function MessageHistoryList(props: MessageHistoryListProps): JSX.Element;
//# sourceMappingURL=MessageHistoryList.d.ts.map