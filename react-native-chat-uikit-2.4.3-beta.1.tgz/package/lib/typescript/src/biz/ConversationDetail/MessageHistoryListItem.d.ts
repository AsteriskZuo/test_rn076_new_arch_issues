import * as React from 'react';
import { ChatMessage } from '../../rename.chat';
import type { MessageHistoryListItemProps } from './types';
export declare function MessageHistoryListItem(props: MessageHistoryListItemProps): JSX.Element;
export type MessageHistoryImageProps = {
    msg: ChatMessage;
    maxWidth?: number;
};
export declare function MessageHistoryImage(props: MessageHistoryImageProps): JSX.Element;
export type MessageHistoryVideoProps = {
    msg: ChatMessage;
    maxWidth?: number;
};
export declare function MessageHistoryVideo(props: MessageHistoryVideoProps): JSX.Element;
export declare const MessageHistoryListItemMemo: React.MemoExoticComponent<typeof MessageHistoryListItem>;
//# sourceMappingURL=MessageHistoryListItem.d.ts.map