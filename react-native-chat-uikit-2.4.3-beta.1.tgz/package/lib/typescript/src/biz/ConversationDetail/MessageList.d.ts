import * as React from 'react';
import { ChatConversationType } from '../../rename.chat';
import type { MessageListRef } from './types';
/**
 * Message List Component.
 *
 * This component can display sent and received messages, display historical messages, play language messages, preview pictures, video messages, download files, and customize behaviors and styles such as previewing pictures, previewing videos, and downloading documents. Custom messages can be added and more. Usually used in conjunction with the `MessageInput` component.
 */
export declare const MessageList: React.ForwardRefExoticComponent<import("../types").PropsWithError & import("../types").PropsWithTest & {
    type: import("./types").ConversationDetailModelType;
    selectType?: import("./types").ConversationSelectModeType;
    convId: string;
    convType: ChatConversationType;
    thread?: import("react-native-chat-sdk/lib/typescript/src/common/ChatMessageThread").ChatMessageThread;
    msgId?: string;
    parentId?: string;
    newThreadName?: string;
    firstMessage?: import("./types").SendMessageProps;
    backgroundImage?: string;
    onClicked?: () => void;
    onClickedItem?: (id: string, model: import("./types").MessageModel | import("./types").SystemMessageModel | import("./types").TimeMessageModel) => boolean | void;
    onLongPressItem?: (id: string, model: import("./types").MessageModel | import("./types").SystemMessageModel | import("./types").TimeMessageModel) => boolean | void;
    onClickedItemAvatar?: (id: string, model: import("./types").MessageModel | import("./types").SystemMessageModel | import("./types").TimeMessageModel) => boolean | void;
    onClickedItemQuote?: (id: string, model: import("./types").MessageModel | import("./types").SystemMessageModel | import("./types").TimeMessageModel) => boolean | void;
    onQuoteMessageForInput?: (model: import("./types").MessageModel) => void;
    onEditMessageForInput?: (model: import("./types").MessageModel) => void;
    containerStyle?: import("react-native").StyleProp<import("react-native").ViewStyle>;
    reportMessageCustomList?: {
        key: string;
        value: string;
    }[];
    listItemRenderProps?: import("./types").MessageListItemRenders & {
        ListItemRender?: import("./types").MessageListItemComponentType;
    };
    recvMessageAutoScroll?: boolean;
    messageLayoutType?: import("../types").MessageLayoutType;
    onInitMenu?: (initItems: import("../types").InitMenuItemsType[]) => import("../types").InitMenuItemsType[];
    onCopyFinished?: (content: string) => void;
    onNoMoreMessage?: () => void;
    onCreateThread?: (params: {
        newName: string;
        parentId: string;
        messageId: string;
    }) => void;
    onOpenThread?: (thread: import("react-native-chat-sdk/lib/typescript/src/common/ChatMessageThread").ChatMessageThread) => void;
    onCreateThreadResult?: (thread?: import("react-native-chat-sdk/lib/typescript/src/common/ChatMessageThread").ChatMessageThread, firstMessage?: import("./types").SendMessageProps) => void;
    onClickedEditThreadName?: (thread: import("react-native-chat-sdk/lib/typescript/src/common/ChatMessageThread").ChatMessageThread) => void;
    onClickedOpenThreadMemberList?: (thread: import("react-native-chat-sdk/lib/typescript/src/common/ChatMessageThread").ChatMessageThread) => void;
    onClickedLeaveThread?: (threadId: string) => void;
    onClickedDestroyThread?: (threadId: string) => void;
    onClickedMultiSelected?: () => void;
    onChangeMultiItems?: (items: import("./types").MessageModel[]) => void;
    onClickedSingleSelect?: (item: import("./types").MessageModel) => void;
    onClickedHistoryDetail?: (item: import("./types").MessageModel) => void;
    onChangeUnreadCount?: (count: number) => void;
    generateThreadName?: (msg: import("./types").MessageModel) => string;
    onChangePinMaskHeight?: (height: number) => void;
    onRequestClosePinMessage?: () => void;
    MessageCustomLongPressMenu?: React.ForwardRefExoticComponent<Omit<import("../types").BizContextMenuProps, "initItems"> & {
        initItems?: import("../types").InitMenuItemsType[];
        layoutType?: "center" | "left";
        hasCancel?: boolean;
        suggestedPosition?: {
            x: number;
            y: number;
        };
        noCoverageArea?: import("../..").ComponentArea;
        maxRowCount?: number;
        unitCountPerRow?: number;
        emojiListPosition?: "bottom" | "top";
    } & React.RefAttributes<import("../types").ContextNameMenuRef>>;
} & React.RefAttributes<MessageListRef>>;
export declare const MessageListMemo: React.MemoExoticComponent<React.ForwardRefExoticComponent<import("../types").PropsWithError & import("../types").PropsWithTest & {
    type: import("./types").ConversationDetailModelType;
    selectType?: import("./types").ConversationSelectModeType;
    convId: string;
    convType: ChatConversationType;
    thread?: import("react-native-chat-sdk/lib/typescript/src/common/ChatMessageThread").ChatMessageThread;
    msgId?: string;
    parentId?: string;
    newThreadName?: string;
    firstMessage?: import("./types").SendMessageProps;
    backgroundImage?: string;
    onClicked?: () => void;
    onClickedItem?: (id: string, model: import("./types").MessageModel | import("./types").SystemMessageModel | import("./types").TimeMessageModel) => boolean | void;
    onLongPressItem?: (id: string, model: import("./types").MessageModel | import("./types").SystemMessageModel | import("./types").TimeMessageModel) => boolean | void;
    onClickedItemAvatar?: (id: string, model: import("./types").MessageModel | import("./types").SystemMessageModel | import("./types").TimeMessageModel) => boolean | void;
    onClickedItemQuote?: (id: string, model: import("./types").MessageModel | import("./types").SystemMessageModel | import("./types").TimeMessageModel) => boolean | void;
    onQuoteMessageForInput?: (model: import("./types").MessageModel) => void;
    onEditMessageForInput?: (model: import("./types").MessageModel) => void;
    containerStyle?: import("react-native").StyleProp<import("react-native").ViewStyle>;
    reportMessageCustomList?: {
        key: string;
        value: string;
    }[];
    listItemRenderProps?: import("./types").MessageListItemRenders & {
        ListItemRender?: import("./types").MessageListItemComponentType;
    };
    recvMessageAutoScroll?: boolean;
    messageLayoutType?: import("../types").MessageLayoutType;
    onInitMenu?: (initItems: import("../types").InitMenuItemsType[]) => import("../types").InitMenuItemsType[];
    onCopyFinished?: (content: string) => void;
    onNoMoreMessage?: () => void;
    onCreateThread?: (params: {
        newName: string;
        parentId: string;
        messageId: string;
    }) => void;
    onOpenThread?: (thread: import("react-native-chat-sdk/lib/typescript/src/common/ChatMessageThread").ChatMessageThread) => void;
    onCreateThreadResult?: (thread?: import("react-native-chat-sdk/lib/typescript/src/common/ChatMessageThread").ChatMessageThread, firstMessage?: import("./types").SendMessageProps) => void;
    onClickedEditThreadName?: (thread: import("react-native-chat-sdk/lib/typescript/src/common/ChatMessageThread").ChatMessageThread) => void;
    onClickedOpenThreadMemberList?: (thread: import("react-native-chat-sdk/lib/typescript/src/common/ChatMessageThread").ChatMessageThread) => void;
    onClickedLeaveThread?: (threadId: string) => void;
    onClickedDestroyThread?: (threadId: string) => void;
    onClickedMultiSelected?: () => void;
    onChangeMultiItems?: (items: import("./types").MessageModel[]) => void;
    onClickedSingleSelect?: (item: import("./types").MessageModel) => void;
    onClickedHistoryDetail?: (item: import("./types").MessageModel) => void;
    onChangeUnreadCount?: (count: number) => void;
    generateThreadName?: (msg: import("./types").MessageModel) => string;
    onChangePinMaskHeight?: (height: number) => void;
    onRequestClosePinMessage?: () => void;
    MessageCustomLongPressMenu?: React.ForwardRefExoticComponent<Omit<import("../types").BizContextMenuProps, "initItems"> & {
        initItems?: import("../types").InitMenuItemsType[];
        layoutType?: "center" | "left";
        hasCancel?: boolean;
        suggestedPosition?: {
            x: number;
            y: number;
        };
        noCoverageArea?: import("../..").ComponentArea;
        maxRowCount?: number;
        unitCountPerRow?: number;
        emojiListPosition?: "bottom" | "top";
    } & React.RefAttributes<import("../types").ContextNameMenuRef>>;
} & React.RefAttributes<MessageListRef>>>;
//# sourceMappingURL=MessageList.d.ts.map