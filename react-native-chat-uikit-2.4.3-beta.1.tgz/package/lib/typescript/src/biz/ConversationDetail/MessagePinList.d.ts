import * as React from 'react';
import { ChatMessage, ChatMessagePinInfo } from '../../rename.chat';
type DeleteButtonStatus = 'request' | 'confirm';
export type MessagePinListRef = {
    addPinMessage: (msg: ChatMessage) => void;
    registerCallback: (onClickedItem: (msg: ChatMessage) => void) => void;
};
export type MessagePinListProps = {
    convId: string;
    convType: number;
    onClickedItem?: (msg: ChatMessage) => void;
    onCountChanged?: (count: number) => void;
    propsRef?: React.RefObject<MessagePinListRef> | ((ref: React.RefObject<MessagePinListRef>) => void);
    onRequestClose?: () => void;
};
export declare function MessagePinList(props: MessagePinListProps): JSX.Element;
export type MessagePinListItemProps = {
    id: string;
    msg: ChatMessage;
    pinInfo?: ChatMessagePinInfo;
    buttonStatus?: DeleteButtonStatus;
    onClickedItem?: (msg: ChatMessage) => void;
    onClickedItemDeleteButton?: (buttonStatus: DeleteButtonStatus, msg: ChatMessage) => void;
};
export declare function MessagePinListItem(props: MessagePinListItemProps): JSX.Element;
export declare const MessagePinListItemMemo: React.MemoExoticComponent<typeof MessagePinListItem>;
export declare function useMessagePinList(props: MessagePinListProps): {
    onClickedItemCallback: (data: ChatMessage) => void;
    onClickedItemDeleteButtonCallback: (buttonStatus: DeleteButtonStatus, msg: ChatMessage) => void;
    dataRef: React.MutableRefObject<MessagePinListItemProps[]>;
    data: readonly MessagePinListItemProps[];
    setData: React.Dispatch<React.SetStateAction<readonly MessagePinListItemProps[]>>;
    ListItem: React.FunctionComponent<MessagePinListItemProps>;
    ref: React.MutableRefObject<import("../../ui/FlatList").FlatListRef<MessagePinListItemProps>>;
    listState: import("../types").ListStateType;
    setListState: React.Dispatch<React.SetStateAction<import("../types").ListStateType>>;
    listType: "FlatList" | "SectionList";
    onRefresh: () => void;
    onMore: () => void;
    isAutoLoad: boolean;
    isSort: boolean;
    isLoadAll: boolean;
    isShowAfterLoaded: boolean;
    loadType: "multiple" | "once";
    isVisibleUpdate: boolean;
    isAutoUpdate: boolean;
    isEventUpdate: boolean;
    refreshing: boolean;
    setRefreshing: React.Dispatch<React.SetStateAction<boolean>>;
    viewabilityConfig: import("react-native").ViewabilityConfig;
    onViewableItemsChanged: (info: {
        viewableItems: import("react-native").ViewToken[];
        changed: import("react-native").ViewToken[];
    }) => void;
    deferSearch: (keyword: string) => void;
    setOnSearch: (onSearch: (keyword: string) => void) => void;
    enableRefresh: boolean;
};
export {};
//# sourceMappingURL=MessagePinList.d.ts.map