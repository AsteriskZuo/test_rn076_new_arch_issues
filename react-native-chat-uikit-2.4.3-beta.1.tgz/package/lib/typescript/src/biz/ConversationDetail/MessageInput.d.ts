import * as React from 'react';
import { ChatConversationType } from '../../rename.chat';
import type { MessageInputRef } from './types';
/**
 * Message Input Component.
 *
 * This component can send text, send emoticons, send files, send pictures, send voice, send files, etc. You can customize the sending menu and add a UI for sending custom messages. Usually this component is used in conjunction with the `MessageList` component.
 */
export declare const MessageInput: React.ForwardRefExoticComponent<import("../types").PropsWithError & import("../types").PropsWithTest & {
    type: import("./types").ConversationDetailModelType;
    selectType?: import("./types").ConversationSelectModeType;
    convId: string;
    convType: ChatConversationType;
    top?: number;
    bottom?: number;
    numberOfLines?: number;
    onClickedSend?: (value: import("./types").SendFileProps | import("./types").SendVoiceProps | import("./types").SendTextProps | import("./types").SendImageProps | import("./types").SendVideoProps | import("./types").SendCardProps) => void;
    closeAfterSend?: boolean;
    onHeightChange?: (height: number) => void;
    onEditMessageFinished?: (model: import("./types").MessageModel) => void;
    onInputMention?: (groupId: string) => void;
    onClickedCardMenu?: () => void;
    onInitMenu?: (initItems: import("../types").InitMenuItemsType[]) => import("../types").InitMenuItemsType[];
    emojiList?: string[];
    multiSelectCount?: number;
    onClickedMultiSelectDeleteButton?: () => void;
    onClickedMultiSelectShareButton?: () => void;
    unreadCount?: number;
    onClickedUnreadCount?: () => void;
    onChangeValue?: (text: string) => void;
} & React.RefAttributes<MessageInputRef>>;
export type MessageInputComponent = typeof MessageInput;
//# sourceMappingURL=MessageInput.d.ts.map