/// <reference types="react" />
import type { MessageThreadMemberListProps } from './types';
/**
 * Message Thread Member List Component.
 */
export declare function MessageThreadMemberList(props: MessageThreadMemberListProps): JSX.Element;
//# sourceMappingURL=MessageThreadMemberList.d.ts.map