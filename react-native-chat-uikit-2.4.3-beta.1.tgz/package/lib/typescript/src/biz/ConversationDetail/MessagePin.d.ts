import * as React from 'react';
import { Animated, GestureResponderHandlers, StyleProp, ViewStyle } from 'react-native';
import { ChatMessage } from '../../rename.chat';
export type MessagePinHolderProps = {
    style?: StyleProp<ViewStyle> | undefined;
};
export declare function MessagePinPlaceholder(props: MessagePinHolderProps): JSX.Element;
export declare class MessagePinPlaceholder2 extends React.PureComponent<MessagePinHolderProps> {
    render(): React.ReactNode;
}
export declare const AnimatedMessagePinPlaceholder: Animated.AnimatedComponent<typeof MessagePinPlaceholder2>;
export type MessagePinProps = {
    convId: string;
    convType: number;
    style?: StyleProp<ViewStyle> | undefined;
    msgPinHeightRef: React.MutableRefObject<number>;
    msgPinHeightAnimate: (toValue: number, onFinished?: ((result: Animated.EndResult) => void) | undefined, offsetToZero?: boolean) => void;
    msgPinLabelTranslateYRef: React.MutableRefObject<number>;
    msgPinLabelTranslateYAnimate: (toValue: number, onFinished?: ((result: Animated.EndResult) => void) | undefined) => void;
    msgPinBackgroundOpacityAnimate: (toValue: number, onFinished?: ((result: Animated.EndResult) => void) | undefined) => void;
    msgPinPlaceHolderHeightAnimate: (toValue: number, onFinished?: ((result: Animated.EndResult) => void) | undefined) => void;
    msgPinLabelCurrentTranslateY: Animated.Value;
    msgPinBackgroundCurrentOpacity: Animated.Value;
    msgPinCurrentHeight: Animated.Value;
    panHandlers: GestureResponderHandlers;
    onChangePinMaskHeight?: (height: number) => void;
    onRequestClose?: () => void;
};
export type MessagePinState = {
    maxListHeight: number;
};
export declare class MessagePin extends React.PureComponent<MessagePinProps, MessagePinState> {
    private listRef;
    private getListRef;
    private uc;
    private tr?;
    private colors?;
    private style?;
    private _maxListHeight;
    private _hadShow;
    constructor(props: MessagePinProps);
    componentDidMount?(): void;
    componentWillUnmount?(): void;
    show(): void;
    hide(): void;
    private onListCountChanged;
    private onRequestClose;
    addPinMessage(msg: ChatMessage): void;
    registerCallback(onClickedItem: (msg: ChatMessage) => void): void;
    private _render;
    render(): React.ReactNode;
}
export declare const AnimatedMessagePin: Animated.AnimatedComponent<typeof MessagePin>;
//# sourceMappingURL=MessagePin.d.ts.map