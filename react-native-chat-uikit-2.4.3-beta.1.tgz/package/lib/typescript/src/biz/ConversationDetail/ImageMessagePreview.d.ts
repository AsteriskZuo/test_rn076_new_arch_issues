import * as React from 'react';
import { StyleProp, ViewStyle } from 'react-native';
import { ChatMessage } from '../../rename.chat';
import type { ContextNameMenuRef, PropsWithBack, PropsWithError } from '../types';
/**
 * Image Message Preview Component properties.
 */
export type ImageMessagePreviewProps = PropsWithBack & PropsWithError & {
    /**
     * Message id.
     */
    msgId: string;
    /**
     * local message id.
     */
    localMsgId: string;
    /**
     * Chat message.
     */
    msg?: ChatMessage;
    /**
     * Container style for the file preview component.
     */
    containerStyle?: StyleProp<ViewStyle>;
    /**
     * Callback function for showing the bottom sheet.
     */
    onShowBottomSheet?: (menuRef: React.RefObject<ContextNameMenuRef>) => void;
};
/**
 * Image Message Preview Component.
 */
export declare function ImageMessagePreview(props: ImageMessagePreviewProps): JSX.Element;
type ImageSize = {
    width: number;
    height: number;
};
export declare function useImageMessagePreview(props: ImageMessagePreviewProps): {
    url: string;
    size: ImageSize;
    menuRef: React.MutableRefObject<ContextNameMenuRef>;
    onRequestCloseMenu: (onFinished?: () => void) => void;
    showBottomSheet: () => void;
};
export {};
//# sourceMappingURL=ImageMessagePreview.d.ts.map