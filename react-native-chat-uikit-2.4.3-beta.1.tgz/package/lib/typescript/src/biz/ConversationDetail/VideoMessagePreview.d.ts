import * as React from 'react';
import { StyleProp, ViewStyle } from 'react-native';
import Video, { LoadError } from 'react-native-video';
import { ChatMessage } from '../../rename.chat';
import type { ContextNameMenuRef, PropsWithBack } from '../types';
/**
 * Video Message Preview Component properties.
 */
export type VideoMessagePreviewProps = PropsWithBack & {
    /**
     * Message id.
     */
    msgId: string;
    /**
     * local message id.
     */
    localMsgId: string;
    /**
     * Chat message.
     */
    msg?: ChatMessage;
    /**
     * Container style for the file preview component.
     */
    containerStyle?: StyleProp<ViewStyle>;
    /**
     * Callback function for showing the bottom sheet.
     */
    onShowBottomSheet?: (menuRef: React.RefObject<ContextNameMenuRef>) => void;
};
/**
 * Video Message Preview Component.
 */
export declare function VideoMessagePreview(props: VideoMessagePreviewProps): JSX.Element;
type ImageSize = {
    width: number;
    height: number;
};
export declare function useVideoMessagePreview(props: VideoMessagePreviewProps): {
    url: string;
    size: ImageSize;
    videoRef: React.MutableRefObject<Video>;
    onVideoError: (error: LoadError) => void;
    onClickedVideo: () => void;
    showLoading: boolean;
    thumbnailUrl: string;
    onEnd: () => void;
    pause: boolean;
    menuRef: React.MutableRefObject<ContextNameMenuRef>;
    onRequestCloseMenu: (onFinished?: () => void) => void;
    showBottomSheet: () => void;
};
export {};
//# sourceMappingURL=VideoMessagePreview.d.ts.map