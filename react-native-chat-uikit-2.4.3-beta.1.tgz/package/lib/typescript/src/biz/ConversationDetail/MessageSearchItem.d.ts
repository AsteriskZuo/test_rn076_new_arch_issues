import * as React from 'react';
import type { MessageSearchItemProps } from './types';
export declare function MessageSearchItem(props: MessageSearchItemProps): JSX.Element;
export declare const MessageSearchItemMemo: React.MemoExoticComponent<typeof MessageSearchItem>;
//# sourceMappingURL=MessageSearchItem.d.ts.map