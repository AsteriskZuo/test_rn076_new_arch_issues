export declare function useUrlPreview(): {
    getUrlFromText: typeof UseUrlPreview.getUrlFromText;
    getUrlListFromText: typeof UseUrlPreview.getUrlListFromText;
    fetchUrlPreview: typeof UseUrlPreview.fetchUrlPreview;
};
export declare class UseUrlPreview {
    static getTitle(html: string): string;
    static getDescription(html: string): string;
    static getImageUrl(html: string): string;
    static fetchUrlPreview(url: string): Promise<{
        url: string;
        title: string;
        description: string;
        imageUrl: string;
    }>;
    static getUrlFromText(text: string): string;
    static getUrlListFromText(text: string): RegExpMatchArray;
}
//# sourceMappingURL=useUrlPreview.d.ts.map