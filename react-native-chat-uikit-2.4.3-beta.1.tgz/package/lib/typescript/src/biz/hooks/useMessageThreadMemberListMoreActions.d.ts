import type { ChatMessageThread } from '../../rename.chat';
import type { BasicActionsProps } from './types';
export type UseMessageThreadMemberListMoreActions = BasicActionsProps & {
    thread: ChatMessageThread;
};
export declare function useMessageThreadMemberListMoreActions(props: UseMessageThreadMemberListMoreActions): {
    onShowMessageThreadMemberListMoreActions: (params: {
        threadId: string;
        memberId: string;
        groupOwner: string;
        /**
         * Callback notification when click kick member.
         */
        onClickedKickMember?: (threadId: string, memberId: string) => void;
    }) => void;
};
//# sourceMappingURL=useMessageThreadMemberListMoreActions.d.ts.map