import type { BasicActionsProps } from './types';
export type UseConversationDetailActionsProps = BasicActionsProps & {};
export declare function useConversationDetailActions(props: UseConversationDetailActionsProps): {
    onShowAVMenu: (params: {
        onClickedVoice?: () => void;
        onClickedVideo?: () => void;
    }) => void;
};
//# sourceMappingURL=useConversationDetailActions.d.ts.map