import type { ChatMessageThread } from '../../rename.chat';
import type { BasicActionsProps } from './types';
export type UseMessageThreadListMoreActions = BasicActionsProps & {};
export declare function useMessageThreadListMoreActions(props: UseMessageThreadListMoreActions): {
    onShowMessageThreadListMoreActions: (params: {
        thread: ChatMessageThread;
        isOwner: boolean;
        /**
         * Callback notification when click edit thread name.
         */
        onClickedEditThreadName?: (thread: ChatMessageThread) => void;
        /**
         * Callback notification when click open thread member list.
         */
        onClickedOpenThreadMemberList?: (thread: ChatMessageThread) => void;
        /**
         * Callback notification when click leave thread.
         */
        onClickedLeaveThread?: (threadId: string) => void;
        /**
         * Callback notification when click destroy thread.
         */
        onClickedDestroyThread?: (threadId: string) => void;
    }) => void;
};
//# sourceMappingURL=useMessageThreadListMoreActions.d.ts.map