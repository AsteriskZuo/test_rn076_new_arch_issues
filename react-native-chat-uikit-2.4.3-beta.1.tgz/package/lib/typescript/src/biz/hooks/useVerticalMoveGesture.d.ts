import { Animated } from 'react-native';
export type useVerticalMoveGestureProps = {
    translateY: Animated.Value;
};
export declare function useVerticalMoveGesture(props: useVerticalMoveGestureProps): {
    panHandlers: import("react-native").GestureResponderHandlers;
};
//# sourceMappingURL=useVerticalMoveGesture.d.ts.map