import { Animated } from 'react-native';
export declare function useHeightAnimation(params: {
    initHeight: number;
    duration?: number;
}): {
    currentHeight: Animated.Value;
    heightAnimate: (toValue: number, onFinished?: (result: Animated.EndResult) => void, offsetToZero?: boolean) => void;
};
//# sourceMappingURL=useHeightAnimation.d.ts.map