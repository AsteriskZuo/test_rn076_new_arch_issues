import * as React from 'react';
import { ChatMessage } from '../../rename.chat';
import type { BottomSheetEmojiListRef } from '../BottomSheetEmojiList';
import type { ConversationDetailModelType, MessageModel, SystemMessageModel, TimeMessageModel } from '../ConversationDetail';
import type { EmojiIconItem, PressedComponentEvent } from '../types';
import type { BasicActionsProps } from './types';
export type UseMessageLongPressActionsProps = BasicActionsProps & {
    /**
     * Callback notification of copy completion.
     */
    onCopyFinished?: (content: string) => void;
    /**
     * Callback notification of quote message for input.
     */
    onQuoteMessageForInput?: (model: MessageModel) => void;
    /**
     * Callback notification of edit message for input.
     */
    onEditMessageForInput?: (model: MessageModel) => void;
    /**
     * Callback notification of show report message.
     */
    showReportMessage?: (model: MessageModel) => void;
    /**
     * Callback notification of delete message.
     */
    onDeleteMessage?: (msg: ChatMessage) => void;
    /**
     * Callback notification of recall message.
     */
    onRecallMessage?: (msg: ChatMessage, fromType: 'send' | 'recv') => void;
    /**
     * Callback notification of translate message.
     */
    onTranslateMessage?: (model: MessageModel) => void;
    /**
     * Callback notification of thread message.
     */
    onThread?: (model: MessageModel) => void;
    /**
     * Callback notification of multi selected.
     */
    onClickedMultiSelected?: () => void;
    /**
     * Callback notification of forward message.
     */
    onForwardMessage?: (model: MessageModel) => void;
    /**
     * Callback notification of pin message.
     */
    onPinMessage?: (model: MessageModel) => void;
};
export declare function useMessageLongPressActions(props: UseMessageLongPressActionsProps): {
    onShowMessageLongPressActions: (params: {
        id: string;
        model: SystemMessageModel | TimeMessageModel | MessageModel;
        emojiList?: EmojiIconItem[];
        onFace?: (face: string) => void;
        convId: string;
        convType: number;
        comType: ConversationDetailModelType;
        event?: PressedComponentEvent;
    }) => void;
};
export type UseEmojiLongPressActionsProps = {
    menuRef: React.RefObject<BottomSheetEmojiListRef>;
};
export declare function useEmojiLongPressActionsProps(props: UseEmojiLongPressActionsProps): {
    onShowEmojiLongPressActions: (emojiList: EmojiIconItem[], onFace?: (face: string) => void) => void;
};
//# sourceMappingURL=useMessageLongPressActions.d.ts.map