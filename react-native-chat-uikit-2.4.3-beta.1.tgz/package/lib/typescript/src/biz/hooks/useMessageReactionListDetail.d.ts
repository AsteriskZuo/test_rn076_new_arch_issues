import * as React from 'react';
import { BottomSheetReactionDetailRef } from '../BottomSheetReactionDetail';
import { MessageModel } from '../ConversationDetail';
export type useMessageReactionListDetailProps = {
    reactionRef: React.RefObject<BottomSheetReactionDetailRef>;
};
export declare function useMessageReactionListDetail(props: useMessageReactionListDetailProps): {
    onShowReactionListDetail: (params: {
        msgModel: MessageModel;
        onRequestCloseReaction: () => void;
        face?: string;
    }) => void;
};
//# sourceMappingURL=useMessageReactionListDetail.d.ts.map