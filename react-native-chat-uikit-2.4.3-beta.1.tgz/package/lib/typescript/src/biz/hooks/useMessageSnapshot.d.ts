import { ChatMessage } from '../../rename.chat';
export declare function useMessageSnapshot(): {
    getMessageSnapshot: (msg?: ChatMessage) => string;
};
//# sourceMappingURL=useMessageSnapshot.d.ts.map