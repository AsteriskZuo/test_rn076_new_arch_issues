import { DataModel } from '../../chat';
import type { ChatMessage } from '../../rename.chat';
export type useDataPriorityProps = {};
export declare function useDataPriority(props: useDataPriorityProps): {
    getContactInfo: (id: string) => DataModel;
    getGroupInfo: (id: string) => DataModel;
    getConvInfo: (id: string, type: number) => DataModel;
    getGroupMemberInfo: (id: string) => DataModel;
    getMsgInfo: (msg: ChatMessage) => DataModel;
};
//# sourceMappingURL=useDataPriority.d.ts.map