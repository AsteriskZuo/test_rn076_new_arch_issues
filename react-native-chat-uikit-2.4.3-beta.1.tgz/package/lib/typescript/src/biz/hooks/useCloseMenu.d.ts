import * as React from 'react';
import type { ContextNameMenuRef } from '../types';
export type UseCloseMenuProps = {
    menuRef: React.RefObject<ContextNameMenuRef>;
};
/**
 * use close menu.
 */
export declare function useCloseMenu(props: UseCloseMenuProps): {
    closeMenu: (onFinished?: () => void) => void;
};
//# sourceMappingURL=useCloseMenu.d.ts.map