export declare function useSaveFile(): {
    getCachePath: () => string;
    getDocumentPath: () => string;
    saveFile: (params: {
        targetPath: string;
        localPath: string;
    }) => Promise<string>;
};
//# sourceMappingURL=useSaveFile.d.ts.map