import * as React from 'react';
import { ComponentArea } from '../../ui/ContextMenu';
import { BizContextMenuProps, ContextNameMenuProps, InitMenuItemsType, MessageMenuHeaderType } from '../types';
export declare function useMessageMenu(props: BizContextMenuProps): {
    items: React.ReactElement<any, string | React.JSXElementConstructor<any>>[];
    updateItems: (items: React.ReactElement[]) => void;
    header: MessageMenuHeaderType;
    headerProps: import("../types").MessageMenuHeaderProps;
    updateProps: (props: BizContextMenuProps) => void;
};
export declare function useMessageNameMenu(props: ContextNameMenuProps): {
    items: InitMenuItemsType[];
    updateItems: (items: InitMenuItemsType[]) => void;
    header: MessageMenuHeaderType;
    headerProps: import("../types").MessageMenuHeaderProps;
    updateProps: (props: ContextNameMenuProps) => void;
    suggestedPosition: {
        x: number;
        y: number;
    };
    maxRowCount: number;
    maxHeight: number;
    noCoverageArea: ComponentArea;
    emojiListPosition: "bottom" | "top";
    unitCountPerRow: number;
    policy: "center" | "side";
};
export declare function useMessageInputBarNameMenu(props: ContextNameMenuProps): {
    items: InitMenuItemsType[];
    updateItems: (items: InitMenuItemsType[]) => void;
    header: MessageMenuHeaderType;
    headerProps: import("../types").MessageMenuHeaderProps;
    updateProps: (props: ContextNameMenuProps) => void;
    suggestedPosition: {
        x: number;
        y: number;
    };
    maxRowCount: number;
    maxHeight: number;
    noCoverageArea: ComponentArea;
    unitCountPerRow: number;
};
//# sourceMappingURL=useMessageMenu.d.ts.map