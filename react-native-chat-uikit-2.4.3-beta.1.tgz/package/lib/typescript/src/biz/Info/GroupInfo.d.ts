import * as React from 'react';
import type { GroupInfoRef } from './types';
/**
 * Group Info Component.
 *
 * If you are a group administrator, you have more operating rights. If you are an ordinary member, you have no group management rights.
 */
export declare const GroupInfo: React.ForwardRefExoticComponent<import("../types").PropsWithBack<any> & import("../types").PropsWithNavigationBar & {
    onClickedNavigationBarButton?: () => void;
    hasSendMessage?: boolean;
    hasAudioCall?: boolean;
    hasVideoCall?: boolean;
    onClearChat?: () => void;
    doNotDisturb?: boolean;
    onDoNotDisturb?: (isDisturb: boolean) => void;
    blockUser?: boolean;
    onBlockUser?: (isBlock: boolean) => void;
    containerStyle?: import("react-native").StyleProp<import("react-native").ViewStyle>;
    onSendMessage?: (id: string) => void;
    onAudioCall?: (id: string) => void;
    onVideoCall?: (id: string) => void;
    onSearch?: (id: string) => void;
    onCopyId?: (id: string) => void;
    onInitMenu?: (initItems: import("../types").InitMenuItemsType[]) => import("../types").InitMenuItemsType[];
    onInitButton?: (initButtons: React.ReactElement<import("../..").BlockButtonProps, string | React.JSXElementConstructor<any>>[]) => React.ReactElement<import("../..").BlockButtonProps, string | React.JSXElementConstructor<any>>[];
} & {
    groupId: string;
    ownerId?: string;
    groupName?: string;
    groupAvatar?: string;
    groupDescription?: string;
    groupMyRemark?: string;
    onParticipant?: (groupId: string) => void;
    onGroupMyRemark?: (groupId: string, remark?: string) => void;
    onGroupName?: (groupId: string, groupName?: string) => void;
    onGroupDescription?: (groupId: string, desc?: string) => void;
    onGroupAvatar?: (groupId: string, avatar?: string) => void;
    onClickedChangeGroupOwner?: (groupId: string, ownerId: string) => void;
    onGroupDestroy?: (groupId: string) => void;
    onGroupQuit?: (groupId: string) => void;
    onGroupKicked?: (groupId: string) => void;
    customItemRender?: (def: React.ReactNode[]) => React.ReactNode[];
} & React.RefAttributes<GroupInfoRef>>;
//# sourceMappingURL=GroupInfo.d.ts.map