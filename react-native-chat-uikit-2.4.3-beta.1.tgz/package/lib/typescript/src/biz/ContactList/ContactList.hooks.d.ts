import * as React from 'react';
import { SectionListData } from 'react-native';
import { ContactModel } from '../../chat';
import type { AlertRef } from '../../ui/Alert';
import type { SectionListRef } from '../../ui/SectionList';
import type { IndexModel, ListIndexProps } from '../ListIndex';
import type { ContextNameMenuRef } from '../types';
import type { ListStateType } from '../types';
import type { ContactListItemComponentType, ContactListItemHeaderComponentType, ContactListItemProps, ContactListProps } from './types';
/**
 * Contact list hook.
 */
export declare function useContactList(props: ContactListProps): {
    sectionListProps: Omit<import("../../ui/SectionList").SectionListProps<ContactListItemProps, IndexModel>, "ref" | "data" | "renderItem">;
    propsSectionListProps: Omit<import("../../ui/SectionList").SectionListProps<ContactListItemProps, IndexModel>, "ref" | "data" | "renderItem">;
    onIndexSelected: (index: number) => void;
    onRequestCloseMenu: (onFinished?: () => void) => void;
    onClickedNewContact: () => void;
    menuRef: React.MutableRefObject<ContextNameMenuRef>;
    alertRef: React.MutableRefObject<AlertRef>;
    onClicked: (data?: ContactModel | undefined) => void;
    onLongPressed: (data?: ContactModel | undefined) => void;
    onCheckClicked: (data?: ContactModel) => void;
    selectedCount: number;
    onClickedCreateGroup: () => void;
    selectedMemberCount: number;
    onClickedAddGroupParticipant: () => void;
    requestCount: number;
    groupCount: number;
    avatarUrl: string;
    tr: (key: string, ...args: any[]) => string;
    ListItemRender: ContactListItemComponentType;
    ListItemHeaderRender: ContactListItemHeaderComponentType;
    contactItems: ({ requestCount }: {
        requestCount: number;
        groupCount: number;
    }) => JSX.Element[];
    ListHeaderComponent: () => JSX.Element;
    onClickedForward: (data?: ContactModel) => void;
    onReload: () => void;
    userId: string;
    onClickedAvatar: () => void;
    sectionsRef: React.MutableRefObject<SectionListData<ContactListItemProps, IndexModel>[]>;
    sections: readonly SectionListData<ContactListItemProps, IndexModel>[];
    setSection: React.Dispatch<React.SetStateAction<readonly SectionListData<ContactListItemProps, IndexModel>[]>>;
    indexTitles: string[];
    setIndexTitles: React.Dispatch<React.SetStateAction<string[]>>;
    AlphabeticIndex: React.FC<ListIndexProps>;
    ref: React.MutableRefObject<SectionListRef<ContactListItemProps, IndexModel>>;
    listState: ListStateType;
    setListState: React.Dispatch<React.SetStateAction<ListStateType>>;
    listType: "FlatList" | "SectionList";
    onRefresh: () => void;
    onMore: () => void;
    isAutoLoad: boolean;
    isSort: boolean;
    isLoadAll: boolean;
    isShowAfterLoaded: boolean;
    loadType: "multiple" | "once";
    isVisibleUpdate: boolean;
    isAutoUpdate: boolean;
    isEventUpdate: boolean;
    refreshing: boolean;
    setRefreshing: React.Dispatch<React.SetStateAction<boolean>>;
    viewabilityConfig: import("react-native").ViewabilityConfig;
    onViewableItemsChanged: (info: {
        viewableItems: import("react-native").ViewToken[];
        changed: import("react-native").ViewToken[];
    }) => void;
    deferSearch: (keyword: string) => void;
    setOnSearch: (onSearch: (keyword: string) => void) => void;
    enableRefresh: boolean;
};
//# sourceMappingURL=ContactList.hooks.d.ts.map