/// <reference types="react" />
import type { ContactListNavigationBarProps } from './types';
type _ContactListNavigationBarProps = ContactListNavigationBarProps & {
    userId?: string;
    selectedCount?: number;
    selectedMemberCount?: number;
    avatarUrl?: string;
    onClickedAddGroupParticipant?: () => void;
    onClickedCreateGroup?: () => void;
    onClickedAvatar?: () => void;
};
export declare const ContactListNavigationBar: (props: _ContactListNavigationBarProps) => JSX.Element;
export {};
//# sourceMappingURL=ContactList.navi.d.ts.map