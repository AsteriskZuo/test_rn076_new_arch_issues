import * as React from 'react';
import { ContactModel } from '../../chat';
import type { ContactSearchModel, SearchContactProps } from './types';
/**
 * Search Contacts component.
 */
export declare function useSearchContact(props: SearchContactProps): {
    onClicked: (data?: ContactModel) => void;
    onCancel: () => void;
    dataRef: React.MutableRefObject<ContactSearchModel[]>;
    data: readonly ContactSearchModel[];
    setData: React.Dispatch<React.SetStateAction<readonly ContactSearchModel[]>>;
    ListItem: React.FunctionComponent<ContactSearchModel>;
    ref: React.MutableRefObject<import("../..").FlatListRef<ContactSearchModel>>;
    listState: import("../types").ListStateType;
    setListState: React.Dispatch<React.SetStateAction<import("../types").ListStateType>>;
    listType: "FlatList" | "SectionList";
    onRefresh: () => void;
    onMore: () => void;
    isAutoLoad: boolean;
    isSort: boolean;
    isLoadAll: boolean;
    isShowAfterLoaded: boolean;
    loadType: "multiple" | "once";
    isVisibleUpdate: boolean;
    isAutoUpdate: boolean;
    isEventUpdate: boolean;
    refreshing: boolean;
    setRefreshing: React.Dispatch<React.SetStateAction<boolean>>;
    viewabilityConfig: import("react-native/types").ViewabilityConfig;
    onViewableItemsChanged: (info: {
        viewableItems: import("react-native/types").ViewToken[];
        changed: import("react-native/types").ViewToken[];
    }) => void;
    deferSearch: (keyword: string) => void;
    setOnSearch: (onSearch: (keyword: string) => void) => void;
    enableRefresh: boolean;
};
//# sourceMappingURL=SearchContact.hooks.d.ts.map