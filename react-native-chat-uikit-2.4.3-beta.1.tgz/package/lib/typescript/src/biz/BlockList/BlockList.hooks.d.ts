import * as React from 'react';
import { SectionListData } from 'react-native';
import { BlockModel } from '../../chat';
import type { AlertRef } from '../../ui/Alert';
import type { IndexModel, ListIndexProps } from '../ListIndex';
import type { ContextNameMenuRef } from '../types';
import type { ListStateType } from '../types';
import type { BlockListItemComponentType, BlockListItemHeaderComponentType, BlockListItemProps, BlockListProps } from './types';
/**
 * Block list hook.
 */
export declare function useBlockList(props: BlockListProps): {
    sectionListProps: Omit<import("../..").SectionListProps<BlockListItemProps, IndexModel>, "ref" | "data" | "renderItem">;
    propsSectionListProps: Omit<import("../..").SectionListProps<BlockListItemProps, IndexModel>, "ref" | "data" | "renderItem">;
    onIndexSelected: (index: number) => void;
    onRequestCloseMenu: (onFinished?: () => void) => void;
    menuRef: React.MutableRefObject<ContextNameMenuRef>;
    alertRef: React.MutableRefObject<AlertRef>;
    onClicked: (data?: BlockModel | undefined) => void;
    onLongPressed: (data?: BlockModel | undefined) => void;
    tr: (key: string, ...args: any[]) => string;
    ListItemRender: BlockListItemComponentType;
    ListItemHeaderRender: BlockListItemHeaderComponentType;
    onError: () => void;
    blockCount: number;
    sectionsRef: React.MutableRefObject<SectionListData<BlockListItemProps, IndexModel>[]>;
    sections: readonly SectionListData<BlockListItemProps, IndexModel>[];
    setSection: React.Dispatch<React.SetStateAction<readonly SectionListData<BlockListItemProps, IndexModel>[]>>;
    indexTitles: string[];
    setIndexTitles: React.Dispatch<React.SetStateAction<string[]>>;
    AlphabeticIndex: React.FC<ListIndexProps>;
    ref: React.MutableRefObject<import("../..").SectionListRef<BlockListItemProps, IndexModel>>;
    listState: ListStateType;
    setListState: React.Dispatch<React.SetStateAction<ListStateType>>;
    listType: "FlatList" | "SectionList";
    onRefresh: () => void;
    onMore: () => void;
    isAutoLoad: boolean;
    isSort: boolean;
    isLoadAll: boolean;
    isShowAfterLoaded: boolean;
    loadType: "multiple" | "once";
    isVisibleUpdate: boolean;
    isAutoUpdate: boolean;
    isEventUpdate: boolean;
    refreshing: boolean;
    setRefreshing: React.Dispatch<React.SetStateAction<boolean>>;
    viewabilityConfig: import("react-native").ViewabilityConfig;
    onViewableItemsChanged: (info: {
        viewableItems: import("react-native").ViewToken[];
        changed: import("react-native").ViewToken[];
    }) => void;
    deferSearch: (keyword: string) => void;
    setOnSearch: (onSearch: (keyword: string) => void) => void;
    enableRefresh: boolean;
};
//# sourceMappingURL=BlockList.hooks.d.ts.map