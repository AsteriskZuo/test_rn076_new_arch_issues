/// <reference types="react" />
import type { SearchBlockProps } from './types';
/**
 * Search Blocks component.
 */
export declare function SearchBlock(props: SearchBlockProps): JSX.Element;
//# sourceMappingURL=SearchBlock.d.ts.map