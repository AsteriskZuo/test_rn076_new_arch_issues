import * as React from 'react';
import { SectionListData } from 'react-native';
import { IndexModel } from '../ListIndex';
import type { BlockListItemProps } from './types';
/**
 * Block list item component.
 */
export declare function BlockListItem(props: BlockListItemProps): JSX.Element;
export declare const BlockListItemMemo: React.MemoExoticComponent<typeof BlockListItem>;
/**
 * Block list item header component.
 */
export declare function BlockListItemHeader(props: SectionListData<BlockListItemProps, IndexModel>): JSX.Element;
export declare const BlockListItemHeaderMemo: React.MemoExoticComponent<typeof BlockListItemHeader>;
//# sourceMappingURL=BlockList.item.d.ts.map