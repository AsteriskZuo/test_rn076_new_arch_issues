import * as React from 'react';
import { BlockModel } from '../../chat';
import type { BlockSearchModel, SearchBlockProps } from './types';
/**
 * Search Blocks component.
 */
export declare function useSearchBlock(props: SearchBlockProps): {
    onClicked: (data?: BlockModel) => void;
    onCancel: () => void;
    dataRef: React.MutableRefObject<BlockSearchModel[]>;
    data: readonly BlockSearchModel[];
    setData: React.Dispatch<React.SetStateAction<readonly BlockSearchModel[]>>;
    ListItem: React.FunctionComponent<BlockSearchModel>;
    ref: React.MutableRefObject<import("../..").FlatListRef<BlockSearchModel>>;
    listState: import("../types").ListStateType;
    setListState: React.Dispatch<React.SetStateAction<import("../types").ListStateType>>;
    listType: "FlatList" | "SectionList";
    onRefresh: () => void;
    onMore: () => void;
    isAutoLoad: boolean;
    isSort: boolean;
    isLoadAll: boolean;
    isShowAfterLoaded: boolean;
    loadType: "multiple" | "once";
    isVisibleUpdate: boolean;
    isAutoUpdate: boolean;
    isEventUpdate: boolean;
    refreshing: boolean;
    setRefreshing: React.Dispatch<React.SetStateAction<boolean>>;
    viewabilityConfig: import("react-native/types").ViewabilityConfig;
    onViewableItemsChanged: (info: {
        viewableItems: import("react-native/types").ViewToken[];
        changed: import("react-native/types").ViewToken[];
    }) => void;
    deferSearch: (keyword: string) => void;
    setOnSearch: (onSearch: (keyword: string) => void) => void;
    enableRefresh: boolean;
};
//# sourceMappingURL=SearchBlock.hooks.d.ts.map