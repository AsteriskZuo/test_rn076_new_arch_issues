/// <reference types="react" />
import { BlockListNavigationBarProps } from './types';
type _BlockListNavigationBarProps = BlockListNavigationBarProps & {
    blockCount?: number;
};
export declare const BlockListNavigationBar: (props: _BlockListNavigationBarProps) => JSX.Element;
export {};
//# sourceMappingURL=BlockList.navi.d.ts.map