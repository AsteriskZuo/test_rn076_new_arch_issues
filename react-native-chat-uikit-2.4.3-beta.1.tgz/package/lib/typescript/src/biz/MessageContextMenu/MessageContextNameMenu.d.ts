import * as React from 'react';
import { ComponentArea } from '../../ui/ContextMenu';
import { InitMenuItemsType } from '../types';
import { ContextNameMenuRef } from '../types';
/**
 * The MessageContextNameMenu component provides menu functionality.
 *
 */
export declare const MessageContextNameMenu: React.ForwardRefExoticComponent<Omit<import("../types").BizContextMenuProps, "initItems"> & {
    initItems?: InitMenuItemsType[];
    layoutType?: "center" | "left";
    hasCancel?: boolean;
    suggestedPosition?: {
        x: number;
        y: number;
    };
    noCoverageArea?: ComponentArea;
    maxRowCount?: number;
    unitCountPerRow?: number;
    emojiListPosition?: "bottom" | "top";
} & React.RefAttributes<ContextNameMenuRef>>;
//# sourceMappingURL=MessageContextNameMenu.d.ts.map