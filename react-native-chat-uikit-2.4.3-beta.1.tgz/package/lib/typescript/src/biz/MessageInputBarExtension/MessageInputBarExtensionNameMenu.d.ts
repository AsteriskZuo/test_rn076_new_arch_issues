import * as React from 'react';
import { InitMenuItemsType } from '../types';
import { ContextNameMenuProps, ContextNameMenuRef } from '../types';
/**
 * The MessageInputBarExtensionNameMenu component provides menu functionality.
 *
 */
export declare const MessageInputBarExtensionNameMenu: React.ForwardRefExoticComponent<Omit<import("../types").BizContextMenuProps, "initItems"> & {
    initItems?: InitMenuItemsType[];
    layoutType?: "center" | "left";
    hasCancel?: boolean;
    suggestedPosition?: {
        x: number;
        y: number;
    };
    noCoverageArea?: import("../..").ComponentArea;
    maxRowCount?: number;
    unitCountPerRow?: number;
    emojiListPosition?: "bottom" | "top";
} & React.RefAttributes<ContextNameMenuRef>>;
export declare function useMessageInputBarExtensionNameMenu(props: ContextNameMenuProps): {
    getMenuHeight: () => 220 | 132;
};
//# sourceMappingURL=MessageInputBarExtensionNameMenu.d.ts.map