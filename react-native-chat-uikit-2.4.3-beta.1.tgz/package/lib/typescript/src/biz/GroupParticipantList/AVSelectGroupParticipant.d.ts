/// <reference types="react" />
import type { GroupParticipantModel } from '../../chat';
import type { GroupParticipantListProps } from './types';
/**
 * Delete Group Participant Component properties.
 */
export type AVSelectGroupParticipantProps = Pick<GroupParticipantListProps, 'groupId' | 'containerStyle' | 'onBack' | 'onError' | 'testMode'> & {
    /**
     * Delete group participant result callback.
     */
    onSelectResult?: (data?: GroupParticipantModel[]) => void;
};
/**
 * Delete Group Participant Component.
 */
export declare function AVSelectGroupParticipant(props: AVSelectGroupParticipantProps): JSX.Element;
//# sourceMappingURL=AVSelectGroupParticipant.d.ts.map