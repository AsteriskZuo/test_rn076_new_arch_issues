/// <reference types="react" />
import { EmitterSubscription, StyleProp, ViewStyle } from 'react-native';
import { DefaultIconImageProps } from '../../ui/Image';
import type { StatusType } from '../types';
export type AvatarProps = DefaultIconImageProps;
/**
 * Avatar component.
 *
 * If the url fails to load, the default avatar is displayed. The default avatar can be customized by setting `Config.personAvatar`.
 *
 * @param props {@link DefaultIconImageProps}
 */
export declare function Avatar(props: AvatarProps): JSX.Element;
/**
 * Group avatar component.
 *
 * If the url fails to load, the default avatar is displayed. The default avatar can be customized by setting `Config.groupAvatar`.
 */
export declare function GroupAvatar(props: AvatarProps): JSX.Element;
export type StatusAvatarProps = AvatarProps & {
    userId?: string;
    onClicked?: () => void;
    statusContainerStyle?: StyleProp<ViewStyle>;
    statusStyle?: StyleProp<ViewStyle>;
    disableStatus?: boolean;
};
/**
 * Status avatar component.
 *
 * Compared with ordinary avatar components, it has custom status. The `presence` service needs to be activated.
 */
export declare function StatusAvatar(props: StatusAvatarProps): JSX.Element;
export declare function useAvatarStatus(): {
    emitAvatarStatusEvent: (...params: any[]) => void;
    addAvatarStatusListener: (listener: (params: {
        status: StatusType;
    }) => void) => EmitterSubscription;
    removeAvatarStatusListener: (sub: EmitterSubscription) => void;
};
//# sourceMappingURL=Avatar.d.ts.map