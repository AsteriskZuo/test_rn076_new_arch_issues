/// <reference types="react" />
import { DefaultIconImageProps } from '../../ui/Image';
export type ThumbImageProps = DefaultIconImageProps;
/**
 * ThumbImage component.
 *
 * If the url fails to load, the default avatar is displayed.
 *
 * @param props {@link DefaultIconImageProps}
 * @returns JSX.Element
 */
export declare function ThumbImage(props: ThumbImageProps): JSX.Element;
//# sourceMappingURL=ThumbImage.d.ts.map