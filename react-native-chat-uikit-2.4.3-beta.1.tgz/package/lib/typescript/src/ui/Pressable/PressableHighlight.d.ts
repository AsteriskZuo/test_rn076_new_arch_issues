import * as React from 'react';
import { ColorValue, PressableProps, View } from 'react-native';
export type PressableHighlightProps = PressableProps & React.RefAttributes<View> & {
    /**
     * The color of the underlay that will show through when the touch is active.
     */
    underlayColor?: ColorValue | undefined;
};
/**
 * Click on the component with the highlighted background. Referenced `Pressable` and `TouchableHighlight`.
 */
export declare function PressableHighlight(props: PressableHighlightProps): JSX.Element;
//# sourceMappingURL=PressableHighlight.d.ts.map