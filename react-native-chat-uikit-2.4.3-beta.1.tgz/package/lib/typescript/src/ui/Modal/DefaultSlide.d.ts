/// <reference types="react" />
import { SlideProps } from './types';
export declare const DefaultSlide: (props: SlideProps) => JSX.Element;
//# sourceMappingURL=DefaultSlide.d.ts.map