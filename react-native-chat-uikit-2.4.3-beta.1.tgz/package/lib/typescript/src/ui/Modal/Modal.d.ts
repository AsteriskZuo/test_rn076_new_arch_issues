/// <reference types="react" />
import type { ModalProps } from './types';
/**
 * @deprecated 2023-11-28 Please use `SlideModal` instead.
 *
 * Mainly solves the effect problem of native modal component `RNModal` display mask.
 */
export declare function Modal(props: ModalProps): JSX.Element;
//# sourceMappingURL=Modal.d.ts.map