/// <reference types="react" />
import type { SimulativeModalProps } from './types';
/**
 * Simulate a modal window.
 */
export declare function SimulativeModal(props: SimulativeModalProps): JSX.Element;
//# sourceMappingURL=SimuModal.d.ts.map