/// <reference types="react" />
import type { SlideModalProps } from './types';
/**
 * Mainly solves the effect problem of native modal component `RNModal` display mask.
 */
export declare function SlideModal(props: SlideModalProps): JSX.Element;
//# sourceMappingURL=SlideModal.d.ts.map