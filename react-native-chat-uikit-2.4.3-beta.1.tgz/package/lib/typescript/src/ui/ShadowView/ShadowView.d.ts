import * as React from 'react';
export type ShadowViewProps = React.PropsWithChildren<{}>;
export declare function ShadowView(props: ShadowViewProps): JSX.Element;
//# sourceMappingURL=ShadowView.d.ts.map