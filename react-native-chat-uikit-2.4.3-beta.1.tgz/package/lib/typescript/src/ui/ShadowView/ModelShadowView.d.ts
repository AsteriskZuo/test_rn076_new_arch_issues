import * as React from 'react';
import { View } from 'react-native';
export type ModelShadowViewProps = React.PropsWithChildren<{
    viewRef: React.RefObject<View>;
}>;
export declare function ModelShadowView(props: ModelShadowViewProps): JSX.Element;
//# sourceMappingURL=ModelShadowView.d.ts.map