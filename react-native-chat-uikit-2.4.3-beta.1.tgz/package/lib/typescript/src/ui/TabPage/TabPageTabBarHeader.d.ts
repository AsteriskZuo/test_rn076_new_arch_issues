import * as React from 'react';
import type { TabPageHeaderProps } from '../../ui/TabPage';
export type TabPageTabBarHeaderProps = TabPageHeaderProps & {
    StateViews?: (React.FC | React.ReactElement | null | undefined)[];
};
/**
 * tab component.
 */
export declare const TabPageTabBarHeader: React.FunctionComponent<TabPageTabBarHeaderProps>;
//# sourceMappingURL=TabPageTabBarHeader.d.ts.map