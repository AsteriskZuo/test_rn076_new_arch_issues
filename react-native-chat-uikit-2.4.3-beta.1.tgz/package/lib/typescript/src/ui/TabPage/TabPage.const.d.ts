export declare const gHeaderHeight = 40;
export declare const gDotHeaderHeight = 6;
export declare const gTabBarHeaderHeight = 52;
export declare const gIndicatorWidth = 28;
export declare const gIndicatorHeight = 4;
export declare const gIndicatorBorderRadius = 2;
export declare const gAnimatedDuration = 250;
//# sourceMappingURL=TabPage.const.d.ts.map