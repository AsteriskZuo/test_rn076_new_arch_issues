/// <reference types="react" />
import type { TabPageHeaderProps } from './types';
export declare function TabPageDotHeader(props: TabPageHeaderProps): JSX.Element;
export type TabPageDotHeaderComponent = typeof TabPageDotHeader;
//# sourceMappingURL=TabPageDotHeader.d.ts.map