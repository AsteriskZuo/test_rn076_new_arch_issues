import { ComponentArea, ComponentArea1 } from './types';
export declare function useContextMenu(): {
    calculateComponentPosition: (params: {
        pressedX: number;
        pressedY: number;
        screenWidth: number;
        screenHeight: number;
        componentWidth: number;
        componentHeight: number;
        noCoverageArea?: ComponentArea;
        policy?: 'side' | 'center';
        padding?: number;
    }) => {
        left?: number;
        top?: number;
        right?: number;
        bottom?: number;
    };
    getComponentVerticesCoordinate: (params: {
        pressedX: number;
        pressedY: number;
        componentX: number;
        componentY: number;
        componentWidth: number;
        componentHeight: number;
    }) => {
        x: number;
        y: number;
    };
    convertComponentCoordinate: (params: ComponentArea) => ComponentArea1;
};
//# sourceMappingURL=useContextMenu.d.ts.map