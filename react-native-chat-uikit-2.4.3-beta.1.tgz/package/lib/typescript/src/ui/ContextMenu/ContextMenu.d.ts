/// <reference types="react" />
import { ContextMenuProps } from './types';
export declare function ContextMenu(props: ContextMenuProps): JSX.Element;
//# sourceMappingURL=ContextMenu.d.ts.map