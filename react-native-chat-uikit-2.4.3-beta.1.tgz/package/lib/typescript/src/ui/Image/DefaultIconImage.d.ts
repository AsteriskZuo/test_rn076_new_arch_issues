/// <reference types="react" />
import type { ImageStyle, StyleProp } from 'react-native';
export type DefaultIconImageProps = {
    url?: string | undefined;
    localIcon?: number;
    size: number;
    borderRadius?: number;
    style?: StyleProp<ImageStyle>;
    defaultStyle?: StyleProp<ImageStyle>;
    cache?: 'default' | 'reload' | 'force-cache' | 'only-if-cached' | undefined;
};
export declare function DefaultIconImage(props: DefaultIconImageProps): JSX.Element;
//# sourceMappingURL=DefaultIconImage.d.ts.map