/// <reference types="react" />
export type TriangleViewProps = {
    rotate?: string;
    side1?: number;
    side2?: number;
    side3?: number;
};
export declare function TriangleView(props: TriangleViewProps): JSX.Element;
export declare function TriangleViewIos(props: TriangleViewProps): JSX.Element;
export declare function TriangleViewAndroid(props: TriangleViewProps): JSX.Element;
//# sourceMappingURL=TriangleView.d.ts.map