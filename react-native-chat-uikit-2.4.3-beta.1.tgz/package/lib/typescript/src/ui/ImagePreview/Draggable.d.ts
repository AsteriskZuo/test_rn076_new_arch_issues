import * as React from 'react';
import { StyleProp, ViewStyle } from 'react-native';
export type DraggableProps = React.PropsWithChildren<{
    containerStyle?: StyleProp<ViewStyle>;
    onChangeMoved?: (x: number, y: number) => void;
}>;
export declare function Draggable(props: DraggableProps): JSX.Element;
export declare function Draggable2(props: DraggableProps): JSX.Element;
//# sourceMappingURL=Draggable.d.ts.map