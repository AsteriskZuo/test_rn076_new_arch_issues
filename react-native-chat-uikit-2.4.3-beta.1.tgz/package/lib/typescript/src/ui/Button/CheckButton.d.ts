/// <reference types="react" />
import type { ImageStyle, StyleProp } from 'react-native';
export type CheckButtonProps = {
    checked: boolean;
    disable?: boolean;
    onClicked?: () => void;
    style?: StyleProp<ImageStyle>;
};
export declare function CheckButton(props: CheckButtonProps): JSX.Element;
//# sourceMappingURL=CheckButton.d.ts.map