/// <reference types="react" />
import type { ColorValue, StyleProp, TextStyle } from 'react-native';
import { TextProps } from './Text';
export type HighUrlProps = Omit<TextProps, 'children'> & {
    /**
     * A string that may contain multiple url keywords.
     */
    content: string;
    urlColors?: ColorValue[];
    textColors?: ColorValue[];
    containerStyle?: StyleProp<TextStyle>;
    urlStyle?: StyleProp<TextStyle>;
    otherStyle?: StyleProp<TextStyle>;
    numberOfLines?: number | undefined;
    onClicked?: (url: string) => void;
};
export declare function HighUrl(props: HighUrlProps): JSX.Element;
export declare function useHighUrl(props: HighUrlProps): {
    getContent: () => JSX.Element[];
};
//# sourceMappingURL=HighUrl.d.ts.map