/// <reference types="react" />
import type { ColorValue, StyleProp, TextStyle } from 'react-native';
import { TextProps } from './Text';
export type HighTextProps = Omit<TextProps, 'children'> & {
    keyword: string;
    content: string;
    highColors?: ColorValue[];
    textColors?: ColorValue[];
    containerStyle?: StyleProp<TextStyle>;
    numberOfLines?: number | undefined;
};
/**
 * Highlight keywords.
 *
 * **Note** Exceeding the width is not considered.
 */
export declare function HighText(props: HighTextProps): JSX.Element;
export declare function useHighText(props: HighTextProps): {
    getContent: () => JSX.Element[];
};
export declare function useHighText2(props: HighTextProps): {
    getContent: () => JSX.Element[];
};
//# sourceMappingURL=HighText.d.ts.map