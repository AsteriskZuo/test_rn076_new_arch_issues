/// <reference types="react" />
import type { SimpleToastProps } from './types';
export declare function SimpleToast(props: SimpleToastProps): JSX.Element;
//# sourceMappingURL=SimpleToast.d.ts.map