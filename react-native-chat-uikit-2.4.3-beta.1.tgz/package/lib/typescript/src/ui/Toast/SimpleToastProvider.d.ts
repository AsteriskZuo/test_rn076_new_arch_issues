import * as React from 'react';
import type { SimpleToastType } from './types';
/**
 * Context of the SimpleToast.
 */
export declare const SimpleToastContext: React.Context<SimpleToastType>;
/**
 * Properties of the SimpleToast context.
 */
type SimpleToastContextProps = React.PropsWithChildren<{}>;
/**
 * The SimpleToast context's provider.
 */
export declare function SimpleToastContextProvider(props: SimpleToastContextProps): JSX.Element;
/**
 * Get the SimpleToast context's value.
 * @returns The SimpleToast context's value.
 */
export declare function useSimpleToastContext(): SimpleToastType;
export {};
//# sourceMappingURL=SimpleToastProvider.d.ts.map