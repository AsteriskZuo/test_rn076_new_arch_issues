/// <reference types="react" />
import type { ToastViewProps } from './types';
export declare function ToastView(props: ToastViewProps): JSX.Element;
//# sourceMappingURL=ToastView.d.ts.map