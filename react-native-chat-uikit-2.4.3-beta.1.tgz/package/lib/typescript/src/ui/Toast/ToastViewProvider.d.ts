import * as React from 'react';
import type { ToastViewType } from './types';
/**
 * Context of the ToastView.
 */
export declare const ToastViewContext: React.Context<ToastViewType>;
/**
 * Properties of the ToastView context.
 */
type ToastViewContextProps = React.PropsWithChildren<{}>;
/**
 * The ToastView context's provider.
 */
export declare function ToastViewContextProvider(props: ToastViewContextProps): JSX.Element;
/**
 * Get the ToastView context's value.
 * @returns The ToastView context's value.
 */
export declare function useToastViewContext(): ToastViewType;
export {};
//# sourceMappingURL=ToastViewProvider.d.ts.map