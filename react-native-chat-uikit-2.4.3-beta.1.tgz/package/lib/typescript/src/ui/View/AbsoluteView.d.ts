/// <reference types="react" />
import type { AbsoluteViewProps } from './types';
export declare function AbsoluteView(props: AbsoluteViewProps): JSX.Element;
//# sourceMappingURL=AbsoluteView.d.ts.map