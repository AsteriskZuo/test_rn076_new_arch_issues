export declare class SingletonObjects {
    private static _instances;
    static getInstance<T>(c: new () => T): T;
    static getInstanceWithParams<T, P = any>(c: new (params: P) => T, params: P): T;
}
//# sourceMappingURL=singleton.d.ts.map