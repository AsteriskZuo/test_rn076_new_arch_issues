export declare function splitStringWithDelimiter(str: string, delimiter: string): any[];
export declare const gUrlPattern: RegExp;
export declare function splitStringByUrl(str: string, urlRegex?: RegExp): string[];
//# sourceMappingURL=split.d.ts.map