import { ChatConversationType, ChatMessage, ChatPresence } from '../rename.chat';
import type { UserData } from './types';
import type { NewRequestModel } from './types.ui';
/**
 * Get user info from message.
 */
export declare function userInfoFromMessage(msg?: ChatMessage | undefined | null): UserData | undefined;
/**
 * Set user info to message.
 */
export declare function setUserInfoToMessage(params: {
    msg: ChatMessage;
    user?: UserData;
}): void;
/**
 * Get message snapshot.
 */
export declare function getMessageSnapshot(msg?: ChatMessage): string;
export declare function getMessageSnapshotParams(msg?: ChatMessage): any[];
/**
 * Get new request from message.
 */
export declare function getNewRequest(msg?: ChatMessage): NewRequestModel | undefined;
export declare function createForwardMessage(params: {
    msgs: ChatMessage[];
    targetId: string;
    targetType: ChatConversationType;
    getSummary: (msgs: ChatMessage[]) => string;
}): ChatMessage | undefined;
export declare class PresenceUtil {
    static convertToProtocol: (status: string) => string;
    static convertFromProtocol: (status?: ChatPresence) => string;
}
//# sourceMappingURL=utils.d.ts.map