declare const VERSION = "2.4.3-beta.1";
export default VERSION;
//# sourceMappingURL=version.d.ts.map