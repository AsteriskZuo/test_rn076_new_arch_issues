// This file is generated automatically. Please do not edit it manually. If necessary, you can run the 'scripts/generate-version.js' script to generate it again.

const VERSION = '1.0.5';
export default VERSION;
