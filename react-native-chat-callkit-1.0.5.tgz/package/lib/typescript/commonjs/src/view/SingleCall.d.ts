import * as React from 'react';
import type { CallUser } from '../call/CallUser';
import { CallEndReason } from '../enums';
import { BasicCall, BasicCallProps, BasicCallState } from './BasicCall';
/**
 * Single call attribute object.
 */
export type SingleCallProps = BasicCallProps & {
    /**
     * The invitee ID.
     */
    inviteeId: string;
    /**
     * The invitee Name.
     */
    inviteeName?: string;
    /**
     * The invitee Avatar url.
     */
    inviteeAvatar?: string;
    /**
     * Notification that the other party has joined.
     */
    onPeerJoined?: () => void;
};
/**
 * Single call status object.
 */
export type SingleCallState = BasicCallState & {
    /**
     * Whether the peer has joined.
     */
    peerJoinChannelSuccess: boolean;
    /**
     * Whether the peer has disables the camera.
     */
    peerMuteVideo: boolean;
    /**
     * Whether the peer has disabled the microphone.
     */
    peerMuteAudio: boolean;
    /**
     * The peer RTC channel ID.
     */
    peerUid: number;
    /**
     * Whether to switch the local camera.
     */
    isSwitchVideo: boolean;
    /**
     * The peer information. Include name and avatar.
     */
    peerInfo?: CallUser;
};
/**
 * Single call UI component. The common part is detailed here. {@link BasicCall}
 */
export declare class SingleCall extends BasicCall<SingleCallProps, SingleCallState> {
    constructor(props: SingleCallProps);
    protected init(): void;
    protected unInit(): void;
    private startCall;
    private updateBottomButtons;
    protected renderMiniVideoIsSelf(): boolean | null;
    private getUserInfo;
    private getName;
    private getAvatar;
    private getPeerInfo;
    onSwitchVideo: () => void;
    onRequestJoin(params: {
        channelId: string;
        userId: string;
        userChannelId: number;
        userRTCToken: string;
    }): void;
    onRemoteUserJoined(params: {
        channelId: string;
        userChannelId: number;
        userId: string;
    }): void;
    onSelfJoined(params: {
        channelId: string;
        userChannelId: number;
        userId: string;
        elapsed: number;
    }): void;
    onRemoteUserOffline(params: {
        channelId: string;
        userChannelId: number;
        userId: string;
    }): void;
    onRemoveRemoteUser(params: {
        channelId: string;
        userChannelId?: number;
        userId: string;
        reason?: CallEndReason;
    }): void;
    onSelfLeave(params: {
        channelId: string;
        userChannelId: number;
        userId: string;
    }): void;
    onRemoteUserMuteVideo(params: {
        channelId: string;
        userId: string;
        userChannelId: number;
        muted: boolean;
    }): void;
    onRemoteUserMuteAudio(params: {
        channelId: string;
        userId: string;
        userChannelId: number;
        muted: boolean;
    }): void;
    protected renderSelfVideo(): React.ReactNode;
    protected renderPeerVideo(): React.ReactNode;
    protected renderMiniVideo(): React.ReactNode;
    protected renderFullVideo(): React.ReactNode;
    protected renderTopBar(): React.ReactNode;
    protected renderAvatar(): React.ReactNode;
    protected renderFloatAudio(): React.ReactNode;
    protected renderFloatVideo(): React.ReactNode;
    protected renderContent(): React.ReactNode;
    protected renderBlur(): React.ReactNode;
    protected renderBody(): React.ReactNode;
}
//# sourceMappingURL=SingleCall.d.ts.map