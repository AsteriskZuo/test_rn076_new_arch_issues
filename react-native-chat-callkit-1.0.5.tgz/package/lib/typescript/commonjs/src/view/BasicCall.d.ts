import * as React from 'react';
import type { VideoViewSetupMode } from 'react-native-agora';
import type { CallError } from '../call/CallError';
import type { CallManagerImpl } from '../call/CallManagerImpl';
import type { CallUser } from '../call/CallUser';
import type { CallViewListener } from '../call/CallViewListener';
import { CallEndReason, CallState, CallType } from '../enums';
export declare const StateBarHeight: number;
/**
 * Bottom call button group type.
 */
export type BottomButtonType = 'inviter-video' | 'inviter-audio' | 'inviter-timeout' | 'invitee-video-init' | 'invitee-video-loading' | 'invitee-video-calling' | 'invitee-audio-init' | 'invitee-audio-loading' | 'invitee-audio-calling';
/**
 * The property object of the basic call component.
 */
export type BasicCallProps = {
    /**
     * Inviter ID.
     */
    inviterId: string;
    /**
     * Inviter name.
     */
    inviterName?: string;
    /**
     * Inviter avatar url.
     */
    inviterAvatar?: string;
    /**
     * Current user ID.
     */
    currentId: string;
    /**
     * Current user name.
     */
    currentName?: string;
    /**
     * Current avatar url.
     */
    currentAvatar?: string;
    /**
     * Call request timeout value. The unit is milliseconds (ms).
     */
    timeout?: number;
    /**
     * Bottom call button group type value.
     */
    bottomButtonType?: BottomButtonType;
    /**
     * Whether to disable the camera.
     */
    muteVideo?: boolean;
    /**
     * call type. video or audio.
     */
    callType: 'audio' | 'video';
    /**
     * An enumerated type of call state value.
     * The default is connecting. This parameter is not commonly used.
     */
    callState?: CallState;
    /**
     * Whether the page is minimized. Typical application: After minimizing, the component becomes a floating button that can be dragged and restored to full-screen display mode. Default is false.
     */
    isMinimize?: boolean;
    /**
     * Whether to enable test mode. Please set it to false or undefined during official development. Default is false.
     */
    isTest?: boolean;
    /**
     * Callback notification when the call is hung up. Called when the user clicks the hangup button or when the corresponding timeout occurs.
     */
    onHangUp?: () => void;
    /**
     * Cancel call notifications. Before the call is connected, click the hang up button to trigger the cancellation callback notification.
     */
    onCancel?: () => void;
    /**
     * Reject callback notification. Called when the invitee clicks the decline button.
     */
    onRefuse?: () => void;
    /**
     * Request to turn off notifications. Under the condition that no error occurs, the callback is triggered by clicking hangup, cancel, reject, timeout and other operations. In the callback, the user needs to destroy the component, release related resources and other operations. For similar behaviors, refer to the `Modal` UI component.
     */
    onClose: (elapsed: number, reason?: CallEndReason) => void;
    /**
     * An error notification occurred. An error triggered by any behavior will generate a `CallError` object, and the error object will prompt to fix the problem or perform other operations.
     */
    onError?: (error: CallError) => void;
    /**
     * Call UI component initialization completion notification. Components need to consume time and space resources during initialization. After the initialization is completed, the user will be notified, and the user can perform their own initialization operations.
     */
    onInitialized?: () => void;
    /**
     * Join the channel notification yourself.
     */
    onSelfJoined?: () => void;
};
/**
 * The state object of the base component.
 */
export type BasicCallState = {
    /**
     * Whether self have already joined the channel.
     */
    joinChannelSuccess: boolean;
    /**
     * own channel ID.
     */
    selfUid: number;
    /**
     * Setting mode of the view value.
     */
    setupMode: VideoViewSetupMode;
    /**
     * Whether to use open mode. Speech can be played through the device speaker in development mode. The default is false.
     */
    isInSpeaker: boolean;
    /**
     * Whether to disable the microphone function.
     */
    muteMicrophone: boolean;
    /**
     * Bottom call button group type value.
     */
    bottomButtonType: BottomButtonType;
    /**
     * Whether to disable the camera.
     */
    muteVideo: boolean;
    /**
     * An enumerated type of call state value.
     */
    callState: CallState;
    /**
     * Whether the page is minimized. Typical application: After minimizing, the component becomes a floating button that can be dragged and restored to full-screen display mode.
     */
    isMinimize: boolean;
    /**
     * call duration. The unit is milliseconds (ms). Default is 0.
     */
    elapsed: number;
    /**
     * The end of call reason value.
     */
    reason?: CallEndReason;
    /**
     * The error information.
     */
    error?: CallError;
};
/**
 * Basic object for calling UI components.
 */
export declare abstract class BasicCall<Props extends BasicCallProps, State extends BasicCallState> extends React.Component<Props, State> implements CallViewListener {
    protected _inviteeTimer?: NodeJS.Timeout;
    protected _startPreview: boolean;
    protected channelId: string;
    protected callId: string;
    constructor(props: Props);
    componentDidMount(): void;
    componentWillUnmount(): void;
    protected manager?: CallManagerImpl;
    protected isInviter: boolean;
    protected abstract init(): void;
    protected abstract unInit(): void;
    protected getUserInfoAsync(userId: string): Promise<CallUser | undefined>;
    onClickHangUp: () => void;
    onClickSpeaker: () => void;
    onClickMicrophone: () => void;
    onClickVideo: () => void;
    onClickRecall: () => void;
    onClickClose: () => void;
    onClickAccept: () => void;
    switchCamera: () => void;
    protected renderBody(): React.ReactNode;
    render(): React.ReactNode;
    protected renderBackground(): React.ReactNode;
    protected renderBottomMenu(): React.ReactNode;
    onCallEnded(params: {
        channelId: string;
        callType: CallType;
        endReason: CallEndReason;
        elapsed: number;
    }): void;
    onCallOccurError(params: {
        channelId: string;
        error: CallError;
    }): void;
    onRemoteUserJoined(params: {
        channelId: string;
        userChannelId: number;
        userId: string;
    }): void;
    onSelfJoined(params: {
        channelId: string;
        userChannelId: number;
        userId: string;
        elapsed: number;
    }): void;
    onRequestJoin(params: {
        channelId: string;
        userId: string;
        userChannelId: number;
        userRTCToken: string;
    }): void;
    onRemoteUserOffline(params: {
        channelId: string;
        userChannelId: number;
        userId: string;
    }): void;
    onRemoveRemoteUser(params: {
        channelId: string;
        userChannelId?: number;
        userId: string;
        reason?: CallEndReason;
    }): void;
    onSelfLeave(params: {
        channelId: string;
        userChannelId: number;
        userId: string;
    }): void;
    onRemoteUserMuteVideo(params: {
        channelId: string;
        userId: string;
        userChannelId: number;
        muted: boolean;
    }): void;
    onRemoteUserMuteAudio(params: {
        channelId: string;
        userId: string;
        userChannelId: number;
        muted: boolean;
    }): void;
    onAudioVolumeIndication(_params: {
        channelId: string;
        speakerNumber: number;
        speakers: {
            userId: string;
            userChannelId: number;
            totalVolume: number;
        }[];
    }): void;
    onLocalVideoStateChanged(params: {
        channelId: string;
        userId: string;
        userChannelId: number;
        muted: boolean;
    }): void;
    onLocalAudioStateChanged(params: {
        channelId: string;
        userId: string;
        userChannelId: number;
        muted: boolean;
    }): void;
}
//# sourceMappingURL=BasicCall.d.ts.map