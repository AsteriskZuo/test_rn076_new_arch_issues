import * as React from 'react';
import { CallUser } from '../call';
import { CallEndReason } from '../enums';
import type { User } from '../types';
import { BasicCall, BasicCallProps, BasicCallState } from './BasicCall';
/**
 * Property of the inviter list UI component in the call.
 */
export type InviteeListProps = {
    /**
     * People who have been invited to the current meeting, including yourself.
     */
    selectedIds: string[];
    /**
     * Maximum number of invites. See {@link VideoMaxCount} or {@link AudioMaxCount}
     */
    maxCount: number;
    /**
     * Callback notification that the invite UI component is closed.
     *
     * @param addedIds: A list of inviters other than those who are in a call.
     * @param addeds: (optional) Information about the invitee. Include name and avatar.
     */
    onClose: (addedIds: string[], addeds?: CallUser[]) => void;
    /**
     * Callback notification for canceling the invitation.
     */
    onCancel: () => void;
};
/**
 * The property object of the multi-person call UI component.
 */
export type MultiCallProps = BasicCallProps & {
    /**
     * List of IDs of invitees.
     */
    inviteeIds: string[];
    /**
     * Inviter UI component.
     * Typical application: During a call, use this component to invite people to join the call again.
     */
    inviteeList?: {
        InviteeList: (props: InviteeListProps) => JSX.Element;
        props?: InviteeListProps;
    };
    /**
     * Information about the invitee. Include name and avatar.
     */
    invitees?: CallUser[];
    /**
     * The ID of the multi call.
     */
    groupId?: string;
    /**
     * The name of the multi call.
     */
    groupName?: string;
    /**
     * The avatar of the multi call.
     * Use group avatars when calls are minimized.
     */
    groupAvatar?: string;
};
/**
 * The state object of the multi call component.
 */
export type MultiCallState = BasicCallState & {
    /**
     * List of IDs of invitees.
     */
    inviteeIds: string[];
    /**
     * Status information of inviter and invitee. including myself.
     */
    users: User[];
    /**
     * Whether the video is zoomed in full screen alone
     */
    isFullVideo: boolean;
    /**
     * The number of current callers.
     */
    usersCount: number;
    /**
     * Whether to show the invite button.
     */
    showInvite: boolean;
    /**
     * The ID of the person displayed in full screen.
     */
    fullId?: string;
    /**
     * The channel ID of the person displayed in full screen.
     */
    fullChannelId?: number;
};
/**
 * Multi call UI component. The common part is detailed here. {@link BasicCall}
 */
export declare class MultiCall extends BasicCall<MultiCallProps, MultiCallState> {
    private _videoTabRef?;
    private _cache;
    constructor(props: MultiCallProps);
    protected static removeDuplicateData(users: User[]): User[];
    protected init(): void;
    protected unInit(): void;
    private onInviteCall;
    private startCall;
    private updateBottomButtons;
    private updateUser;
    private updateUsers;
    private removeUser;
    private getUserInfoList;
    private updateUserInfoList;
    inviteUser: () => void;
    onRequestJoin(params: {
        channelId: string;
        userId: string;
        userChannelId: number;
        userRTCToken: string;
    }): void;
    onRemoteUserJoined(params: {
        channelId: string;
        userChannelId: number;
        userId: string;
    }): void;
    onSelfJoined(params: {
        channelId: string;
        userChannelId: number;
        userId: string;
        elapsed: number;
    }): void;
    onRemoteUserOffline(params: {
        channelId: string;
        userChannelId: number;
        userId: string;
    }): void;
    onRemoveRemoteUser(params: {
        channelId: string;
        userChannelId?: number;
        userId: string;
        reason?: CallEndReason;
    }): void;
    onSelfLeave(params: {
        channelId: string;
        userChannelId: number;
        userId: string;
    }): void;
    onRemoteUserMuteVideo(params: {
        channelId: string;
        userId: string;
        userChannelId: number;
        muted: boolean;
    }): void;
    onRemoteUserMuteAudio(params: {
        channelId: string;
        userId: string;
        userChannelId: number;
        muted: boolean;
    }): void;
    onAudioVolumeIndication(params: {
        channelId: string;
        speakerNumber: number;
        speakers: {
            userId: string;
            userChannelId: number;
            totalVolume: number;
        }[];
    }): void;
    onLocalVideoStateChanged(params: {
        channelId: string;
        userId: string;
        userChannelId: number;
        muted: boolean;
    }): void;
    onLocalAudioStateChanged(params: {
        channelId: string;
        userId: string;
        userChannelId: number;
        muted: boolean;
    }): void;
    private cloneUsers;
    private compareUsers;
    protected renderAudio(): React.ReactNode;
    protected renderVideo(): React.ReactNode;
    protected renderTopBar(): React.ReactNode;
    protected renderFloat(): React.ReactNode;
    protected renderContent(): React.ReactNode;
    protected renderInviteeList(): React.ReactNode;
    protected renderBody(): React.ReactNode;
}
//# sourceMappingURL=MultiCall.d.ts.map