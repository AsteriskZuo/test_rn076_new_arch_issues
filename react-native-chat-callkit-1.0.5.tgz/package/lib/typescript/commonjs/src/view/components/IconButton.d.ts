import { GestureResponderEvent } from 'react-native';
import { IconName } from './LocalIcon';
type IconButtonProps = {
    disabled?: boolean;
    onPress?: ((event: GestureResponderEvent) => void) | undefined;
    color?: string;
    backgroundColor?: string;
    iconName?: IconName;
    size?: number;
    containerSize?: number;
    isLoading?: boolean;
};
export declare function IconButton(props: IconButtonProps): JSX.Element;
export {};
//# sourceMappingURL=IconButton.d.ts.map