import * as React from 'react';
import { StyleProp, ViewStyle } from 'react-native';
import { IconName } from './LocalIcon';
type SubComponents = {};
type AvatarProps = {
    uri: string | number;
    uriOnError?: IconName | undefined;
    size?: number | undefined;
    radius?: number | undefined;
    containerStyle?: StyleProp<ViewStyle> | undefined;
};
export declare const Avatar: ((props: AvatarProps) => JSX.Element) & SubComponents;
export declare const AvatarMemo: React.MemoExoticComponent<(props: AvatarProps) => JSX.Element>;
export declare function DefaultAvatar(props: Omit<AvatarProps, 'uri' | 'uriOnError'> & {
    userId: string;
    userAvatar?: string;
}): JSX.Element;
export declare const DefaultAvatarMemo: React.MemoExoticComponent<typeof DefaultAvatar>;
export {};
//# sourceMappingURL=Avatar.d.ts.map