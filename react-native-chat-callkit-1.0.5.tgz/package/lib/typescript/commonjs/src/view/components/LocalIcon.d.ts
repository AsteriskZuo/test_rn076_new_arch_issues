import * as React from 'react';
import { ColorValue, ImageStyle, StyleProp, ViewStyle } from 'react-native';
import { ICON_ASSETS } from '../../assets/icons';
export declare enum IconSize {
    ICON_NORMAL = 0,
    ICON_BIGGER = 1,
    ICON_MAX = 2
}
export type IconName = keyof typeof ICON_ASSETS;
export declare const localLocalIcon: <T extends IconName>(name: T, size?: IconSize) => any;
type LocalIconProps = {
    name: IconName;
    color?: ColorValue | undefined;
    size?: number | undefined;
    style?: StyleProp<ImageStyle>;
    containerStyle?: StyleProp<ViewStyle>;
};
export declare function LocalIcon({ name, color, size, style, containerStyle, }: LocalIconProps): JSX.Element;
export declare const LocalIconMemo: React.MemoExoticComponent<typeof LocalIcon>;
export {};
//# sourceMappingURL=LocalIcon.d.ts.map