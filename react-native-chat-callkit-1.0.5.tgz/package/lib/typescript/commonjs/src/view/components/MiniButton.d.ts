import { GestureResponderEvent } from 'react-native';
import { IconName } from './LocalIcon';
type MiniButtonProps = {
    disabled?: boolean;
    onPress?: ((event: GestureResponderEvent) => void) | undefined;
    color?: string;
    backgroundColor?: string;
    iconName?: IconName;
    size?: number;
};
export declare function MiniButton(props: MiniButtonProps): JSX.Element;
export {};
//# sourceMappingURL=MiniButton.d.ts.map