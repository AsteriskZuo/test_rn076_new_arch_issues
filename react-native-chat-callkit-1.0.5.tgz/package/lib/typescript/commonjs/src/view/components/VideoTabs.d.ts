import * as React from 'react';
import { VideoViewSetupMode } from 'react-native-agora';
import type { User } from '../../types';
type VideoTabProps = {
    users: User[];
    index: number;
    onPress?: (params: {
        userId: string;
        userChannelId?: number;
    }) => void;
    setupMode: VideoViewSetupMode;
    isTest?: boolean;
};
type VideoTabState = {
    subUsers: User[];
};
export declare class VideoTab extends React.Component<VideoTabProps, VideoTabState> {
    constructor(props: VideoTabProps);
    componentDidMount?(): void;
    shouldComponentUpdate?(nextProps: Readonly<VideoTabProps>, _: Readonly<VideoTabState>, __: any): boolean;
    componentWillUnmount?(): void;
    private compare;
    update(users: User[]): void;
    protected renderBlur(params: {
        user: User;
        height: number;
        width: number;
    }): React.ReactNode;
    render(): React.ReactNode;
}
type VideoTabsProps = {
    users: User[];
    onPress?: (params: {
        userId: string;
        userChannelId?: number;
    }) => void;
    setupMode: VideoViewSetupMode;
    isTest?: boolean;
};
type VideoTabsState = {
    tabUsers: User[][];
    index: number;
};
export declare class VideoTabs extends React.Component<VideoTabsProps, VideoTabsState> {
    constructor(props: VideoTabsProps);
    componentDidMount?(): void;
    shouldComponentUpdate?(nextProps: Readonly<VideoTabsProps>, _: Readonly<VideoTabsState>, __: any): boolean;
    componentWillUnmount?(): void;
    private compare;
    update(users: User[]): void;
    private initUsers;
    private onIndex;
    render(): React.ReactNode;
}
export {};
//# sourceMappingURL=VideoTabs.d.ts.map