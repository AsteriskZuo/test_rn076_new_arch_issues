import type { ImageComponent } from './index';
declare const ImageWrapper: ImageComponent;
export default ImageWrapper;
//# sourceMappingURL=Image.d.ts.map