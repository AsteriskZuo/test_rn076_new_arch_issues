import type { ImageComponent } from './index';
declare const FastImageWrapper: ImageComponent;
export default FastImageWrapper;
//# sourceMappingURL=FastImage.d.ts.map