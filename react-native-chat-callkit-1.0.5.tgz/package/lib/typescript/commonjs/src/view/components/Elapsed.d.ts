import * as React from 'react';
type ElapsedProps = {
    timer: number;
    color?: string;
};
export declare const ElapsedInternal: (props: ElapsedProps) => JSX.Element;
export declare const Elapsed: React.MemoExoticComponent<(props: ElapsedProps) => import("react/jsx-runtime").JSX.Element>;
export {};
//# sourceMappingURL=Elapsed.d.ts.map