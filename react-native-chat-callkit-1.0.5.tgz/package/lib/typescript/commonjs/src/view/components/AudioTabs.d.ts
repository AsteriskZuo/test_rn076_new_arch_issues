import type { User } from '../../types';
type AudioTabProps = {
    subUsers: User[];
    index: number;
};
export declare function AudioTab(props: AudioTabProps): JSX.Element;
type AudioTabsProps = {
    users: User[];
};
export declare function AudioTabs(props: AudioTabsProps): JSX.Element;
export {};
//# sourceMappingURL=AudioTabs.d.ts.map