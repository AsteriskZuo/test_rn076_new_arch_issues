import type { GestureResponderEvent } from 'react-native';
export type BottomMenuButtonType = 'video' | 'mute-video' | 'speaker' | 'mute-speaker' | 'microphone' | 'mute-microphone' | 'hangup' | 'recall' | 'close' | 'accept' | 'accepting';
type BottomMenuButtonProps = {
    name: BottomMenuButtonType;
    onPress?: ((event: GestureResponderEvent) => void) | undefined;
    backgroundColor?: string;
    disabled?: boolean;
};
export declare function BottomMenuButton(props: BottomMenuButtonProps): JSX.Element;
export {};
//# sourceMappingURL=BottomMenuButton.d.ts.map