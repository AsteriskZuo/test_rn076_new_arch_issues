/**
 * Call enumeration type.
 */
export declare enum CallType {
    Audio1v1 = 0,
    Video1v1 = 1,
    VideoMulti = 2,
    AudioMulti = 3
}
/**
 * An enumerated type of call state.
 */
export declare enum CallState {
    Idle = 0,
    Connecting = 1,
    Calling = 2
}
/**
 * An enumeration type of the reason for the end of the call.
 */
export declare enum CallEndReason {
    HungUp = 0,
    Cancel = 1,
    RemoteCancel = 2,
    RemoteRefuse = 3,
    RemoteBusy = 4,
    NoResponse = 5,
    RemoteNoResponse = 6,
    HandleOnOtherDevice = 7
}
export declare enum CallErrorType {
    /**
     * Real-Time Communications error type.
     */
    RTC = 0,
    /**
     * The signaling error type.
     */
    Signaling = 1,
    /**
     * others
     */
    Others = 2
}
export declare enum CallErrorCode {
    /**
     * Invalid input parameter.
     */
    InvalidParams = 10000,
    /**
     * An abnormal state caused by a logic error. Generally only occurs during the development and implementation phases.
     */
    ExceptionState = 10001,
    /**
     * A type of invalid parameter, high-frequency single column.
     */
    InvalidToken = 10002,
    /**
     * The business logic is abnormal. High frequency single row.
     */
    IsBusy = 10003,
    /**
     * The response timed out. For example: no reply from the other party.
     */
    Timeout = 10004,
    /**
     * Network Error. For example: Failed to send signaling.
     */
    NetworkError = 10005,
    /**
     * Already initialized.
     */
    Initialized = 10006,
    /**
     * other situations.
     */
    Others = 10007
}
//# sourceMappingURL=enums.d.ts.map