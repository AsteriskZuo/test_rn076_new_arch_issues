import * as React from 'react';
import type { CallkitSdkContextType } from '../types';
/**
 * Initializes the property list of 'callkit'.
 */
export type GlobalContainerProps = React.PropsWithChildren<CallkitSdkContextType>;
/**
 * Initializes the entry to 'callkit'.
 *
 * @returns
 */
export declare function GlobalContainer(props: GlobalContainerProps): JSX.Element;
//# sourceMappingURL=GlobalContainer.d.ts.map