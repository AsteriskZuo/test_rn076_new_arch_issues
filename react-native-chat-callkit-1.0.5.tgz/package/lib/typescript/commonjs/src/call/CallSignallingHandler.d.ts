import { CallType } from '../enums';
import { ChatMessage, ChatMessageEventListener } from '../rename.chat';
import * as K from './CallConst';
/**
 * The event monitoring interface of the signaling manager.
 */
export interface CallSignallingListener {
    /**
     * The inviter initiates the invitation and the invitee receives the notice.
     */
    onInvite: (params: {
        callId: string;
        callType: CallType;
        inviterId: string;
        inviterDeviceToken: string;
        channelId: string;
        ts: number;
    }) => void;
    /**
     * The invitee confirms the invitation and the inviter receives the notice.
     */
    onAlert: (params: {
        callId: string;
        callType?: CallType;
        inviteeId: string;
        inviterDeviceToken: string;
        inviteeDeviceToken: string;
        channelId: string;
        ts: number;
    }) => void;
    /**
     * The inviter confirms that the invitee confirms that the invitee receives the notice.
     */
    onAlertConfirm: (params: {
        callId: string;
        callType?: CallType;
        isValid: boolean;
        inviterId: string;
        inviteeDeviceToken: string;
        inviterDeviceToken: string;
        channelId: string;
        ts: number;
    }) => void;
    /**
     * The inviter cancels the invitation, and the invitee receives the notice.
     */
    onInviteCancel: (params: {
        callId: string;
        callType?: CallType;
        inviterId: string;
        inviterDeviceToken: string;
        channelId: string;
        ts: number;
    }) => void;
    /**
     * The invitee `busy/accept/refuse` the invitation, and the inviter receives the notice.
     */
    onInviteReply: (params: {
        callId: string;
        callType?: CallType;
        inviteeId: string;
        reply: typeof K.KeyBusyResult | typeof K.KeyAcceptResult | typeof K.KeyRefuseResult;
        inviteeDeviceToken: string;
        inviterDeviceToken: string;
        channelId: string;
        ts: number;
    }) => void;
    /**
     * The inviter arbitrates the invitee's reply, gives the final choice, and the invitee receives the notice.
     */
    onInviteReplyConfirm: (params: {
        callId: string;
        callType?: CallType;
        inviterId: string;
        reply: typeof K.KeyBusyResult | typeof K.KeyAcceptResult | typeof K.KeyRefuseResult;
        inviterDeviceToken: string;
        inviteeDeviceToken: string;
        channelId: string;
        ts: number;
    }) => void;
    /**
     * The notification is received when someone initiates a video conversion to audio mode.
     */
    onVideoToAudio: () => void;
}
/**
 * Signaling manager.
 */
export declare class CallSignallingHandler implements ChatMessageEventListener {
    private _listener?;
    private _inviteContentHandler;
    init(params: {
        listener: CallSignallingListener;
        inviteContentHandler?: (callType: CallType) => string;
    }): void;
    unInit(): void;
    protected parseCallType(callType: string | number | undefined): CallType | undefined;
    protected parseTs(ts: string | number): number | undefined;
    protected send(callId: string, msg: ChatMessage, onResult: (params: {
        callId: string;
        error?: any;
        msg?: ChatMessage;
    }) => void): void;
    protected inviteContent(callType: CallType): string;
    protected convertToInt(callType: CallType): number;
    /**
     * The inviter sends an invitation message. The invitee receives the notification through {@link CallSignallingListener.onInvite}.
     */
    sendInvite(params: {
        inviteeId: string;
        channelId: string;
        callType: CallType;
        inviterDeviceToken: string;
        callId: string;
        ext?: any;
        onResult: (params: {
            callId: string;
            error?: any;
            msg?: ChatMessage;
        }) => void;
    }): void;
    /**
     * Invitee sends alert message. The inviter is notified by {@link CallSignallingListener.onAlert}.
     */
    sendAlert(params: {
        callId: string;
        inviterId: string;
        inviterDeviceToken: string;
        inviteeDeviceToken: string;
        onResult: (params: {
            callId: string;
            error?: any;
            msg?: ChatMessage;
        }) => void;
    }): void;
    /**
     * The inviter sends a confirmation of the alert. The invitee receives the notification through {@link CallSignallingListener.onAlertConfirm}.
     */
    sendAlertConfirm(params: {
        callId: string;
        inviteeId: string;
        inviterDeviceToken: string;
        inviteeDeviceToken: string;
        isValid: boolean;
        onResult: (params: {
            callId: string;
            error?: any;
            msg?: ChatMessage;
        }) => void;
    }): void;
    /**
     * The inviter sends a message to cancel the invitation. The invitee receives the notification through {@link CallSignallingListener.onInviteCancel}.
     */
    sendInviteCancel(params: {
        callId: string;
        inviteeId: string;
        inviterDeviceToken: string;
        onResult: (params: {
            callId: string;
            error?: any;
            msg?: ChatMessage;
        }) => void;
    }): void;
    /**
     * The invitee sends a confirmation of the invitation. The inviter receives the notification through {@link CallSignallingListener.onInviteReply}.
     */
    sendInviteReply(params: {
        callId: string;
        inviterId: string;
        inviterDeviceToken: string;
        inviteeDeviceToken: string;
        reply: typeof K.KeyBusyResult | typeof K.KeyAcceptResult | typeof K.KeyRefuseResult;
        onResult: (params: {
            callId: string;
            error?: any;
            msg?: ChatMessage;
        }) => void;
    }): void;
    /**
     * The inviter sends the final result of the invitation. The invitee receives the notification through {@link CallSignallingListener.onResult}.
     */
    sendInviteReplyConfirm(params: {
        callId: string;
        inviteeId: string;
        inviterDeviceToken: string;
        inviteeDeviceToken: string;
        reply: typeof K.KeyBusyResult | typeof K.KeyAcceptResult | typeof K.KeyRefuseResult;
        onResult: (params: {
            callId: string;
            error?: any;
            msg?: ChatMessage;
        }) => void;
    }): void;
    /**
     * Someone initiates a video to audio operation, others receive the notification through {@link CallSignallingListener.onVideoToAudio}.
     */
    sendVideoToAudio(): void;
    onMessagesReceived(msgs: ChatMessage[]): void;
    onCmdMessagesReceived(msgs: ChatMessage[]): void;
    private _parseMessage;
}
//# sourceMappingURL=CallSignallingHandler.d.ts.map