import type { ErrorCodeType } from 'react-native-agora';
import { CallErrorCode, CallErrorType } from '../enums';
/**
 * Error message object. Including error code, error type, error description information. Can be formatted as a string.
 */
export declare class CallError {
    private _code;
    private _desc;
    private _type;
    constructor(params: {
        code: CallErrorCode | ErrorCodeType;
        description?: string;
        type?: CallErrorType;
    });
    toString(): string;
    get code(): CallErrorCode | ErrorCodeType;
    get desc(): string;
    get type(): CallErrorType;
}
//# sourceMappingURL=CallError.d.ts.map