import { AudioVolumeInfo, ConnectionChangedReasonType, ConnectionStateType, ErrorCodeType, IRtcEngine, IRtcEngineEventHandler, LocalAudioStreamReason, LocalAudioStreamState, LocalVideoStreamReason, LocalVideoStreamState, RemoteAudioStats, RtcConnection, RtcStats, UserOfflineReasonType, VideoSourceType } from 'react-native-agora';
import { CallEndReason, CallType } from '../enums';
import { ChatClient, ChatMessage } from '../rename.chat';
import * as K from './CallConst';
import { CallError } from './CallError';
import type { CallListener } from './CallListener';
import type { CallManager } from './CallManager';
import type { CallOption } from './CallOption';
import type { CallRelationship } from './CallRelationship';
import { CallSignallingHandler, CallSignallingListener } from './CallSignallingHandler';
import { CallTimeoutHandler, CallTimeoutListener } from './CallTimeoutHandler';
import type { CallUser } from './CallUser';
import type { CallViewListener } from './CallViewListener';
export declare class CallManagerImpl implements CallManager, IRtcEngineEventHandler, CallSignallingListener, CallTimeoutListener {
    private _isInit;
    private _client?;
    private _option;
    private _type?;
    private _listener?;
    private _engine?;
    private _ship;
    private _sig;
    private _timer;
    private _userId;
    private _deviceToken;
    private _users;
    private _device;
    private _userListener?;
    private _elapsed;
    private _intervalId?;
    private _requestRTCToken?;
    private _requestUserMap?;
    private _requestCurrentUser?;
    private _requestUserInfo?;
    constructor();
    protected destructor(): void;
    /**
     * Initialize the `CallManager` object.
     *
     * @param params
     * - option: Important parameters. See {@link CallOption}
     * - listener: Receive notification events. See {@link CallViewListener}
     * - enableLog: Whether to enable logging.
     * - type: The main user gets `rtc token`. See {@link requestRTCToken}
     * - requestRTCToken: Get the rtc token. It needs to be set by the user during initialization and is called when joining the channel. If you don't set it, you can't make a call normally.
     * - requestUserMap: Get the mapping relationship between user chat id and user rtc id. It needs to be set during initialization. If you don't set it, you can't make a call normally.
     * - requestCurrentUser: Get current user information. It needs to be set during initialization.
     * - requestUserInfo: Get user information. If this parameter is not defined, the properties of `SingleCall` or `MultiCall`, or the default value, will be used. If the result is normal, it will be cached. The cache is destroyed after the UI component is unmounted.
     * - onResult: The result of initialization is returned through this parameter. If the argument is `undefined` then initialization is complete, otherwise an error message is given.
     */
    init(params: {
        option: CallOption;
        listener?: CallViewListener;
        enableLog?: boolean;
        type?: 'easemob' | 'agora' | undefined;
        requestRTCToken: (params: {
            appKey: string;
            channelId: string;
            userId: string;
            userChannelId?: number;
            type?: 'easemob' | 'agora' | undefined;
            onResult: (params: {
                data?: any;
                error?: any;
            }) => void;
        }) => void;
        requestUserMap: (params: {
            appKey: string;
            channelId: string;
            userId: string;
            onResult: (params: {
                data?: any;
                error?: any;
            }) => void;
        }) => void;
        requestCurrentUser: (params: {
            onResult: (params: {
                user: CallUser;
                error?: any;
            }) => void;
        }) => void;
        requestUserInfo?: (params: {
            userId: string;
            onResult: (params: {
                user: CallUser;
                error?: any;
            }) => void;
        }) => void;
        requestInviteContent?: (callType: CallType) => string;
        onResult?: (params?: {
            error?: CallError;
        }) => void;
    }): void;
    /**
     * Deinitialize the `CallManager` object.
     * Mainly release resources, stop event notification, stop timer object, etc.
     */
    unInit(): void;
    private initListener;
    private unInitListener;
    protected get option(): CallOption;
    protected get listener(): CallViewListener | undefined;
    protected get ship(): CallRelationship;
    get userId(): string;
    protected get deviceToken(): string;
    protected get signalling(): CallSignallingHandler;
    protected get users(): Map<string, CallUser>;
    protected get timer(): CallTimeoutHandler;
    protected get engine(): IRtcEngine | undefined;
    protected get client(): ChatClient | undefined;
    protected get userListener(): CallListener | undefined;
    get requestRTCToken(): ((params: {
        appKey: string;
        channelId: string;
        userId: string;
        userChannelId?: number;
        type?: "easemob" | "agora" | undefined;
        onResult: (params: {
            data?: any;
            error?: any;
        }) => void;
    }) => void) | undefined;
    get requestUserMap(): ((params: {
        appKey: string;
        channelId: string;
        userId: string;
        onResult: (params: {
            data?: any;
            error?: any;
        }) => void;
    }) => void) | undefined;
    get requestCurrentUser(): ((params: {
        onResult: (params: {
            user: CallUser;
            error?: any;
        }) => void;
    }) => void) | undefined;
    get requestUserInfo(): ((params: {
        userId: string;
        onResult: (params: {
            user: CallUser;
            error?: any;
        }) => void;
    }) => void) | undefined;
    get elapsed(): number;
    set elapsed(e: number);
    protected _clearElapsed(): void;
    createChannelId(): string;
    addListener(listener: CallListener): void;
    removeListener(_: CallListener): void;
    setLogHandler(handler: ((message?: any, ...optionalParams: any[]) => void) | undefined): void;
    addViewListener(listener: CallViewListener): void;
    removeViewListener(_: CallViewListener): void;
    /**
     * Initializes the RTC object.
     */
    initRTC(): void;
    /**
     * Deinitialize the RTC object.
     */
    unInitRTC(): void;
    setCurrentUser(currentUser: CallUser): void;
    clear(): void;
    getCurrentCallId(): string | undefined;
    getCurrentChannelId(): string | undefined;
    /**
     * An invitation to start a 1v1 audio call. The result of this operation is returned by `onResult`, if it is successful, it returns `callId`, otherwise it returns `error`.
     *
     * @params params
     * - inviteeId: Invitee ID.
     * - channelId: The unique identifier of the call channel. It is recommended to create via {@link CallManagerImpl.createChannelId}. This property is highly recommended for preservation.
     * - rtcToken: The token obtained through the `appserver` request using `channelId`.
     * - extension: any.
     * - onResult: Returns `callId` on success, `error` on failure. The `callId` property is highly recommended for preservation.
     */
    startSingleAudioCall(params: {
        inviteeId: string;
        channelId: string;
        extension?: any;
        onResult: (params: {
            callId?: string;
            error?: CallError;
        }) => void;
    }): void;
    /**
     * An invitation to start a 1v1 video call. The result of this operation is returned by `onResult`, if it is successful, it returns `callId`, otherwise it returns `error`.
     *
     * If the network is not good, you can try to switch to audio mode. {@link videoToAudio}
     *
     * @params params
     * - inviteeId: Invitee ID.
     * - channelId: The unique identifier of the call channel. It is recommended to create via {@link createChannelId}. This property is highly recommended for preservation.
     * - rtcToken: The token obtained through the `appserver` request using `channelId`.
     * - extension: any.
     * - onResult: Returns `callId` on success, `error` on failure. The `callId` property is highly recommended for preservation.
     */
    startSingleVideoCall(params: {
        inviteeId: string;
        channelId: string;
        extension?: any;
        onResult: (params: {
            callId?: string;
            error?: CallError;
        }) => void;
    }): void;
    /**
     * An invitation to start a multi audio/video call. The result of this operation is returned by `onResult`, if it is successful, it returns `callId`, otherwise it returns `error`.
     *
     * If the network is not good, you can try to switch to audio mode. {@link videoToAudio}
     *
     * During the call, you can invite the dropped person or others again.
     *
     * @params params
     * - inviteeIds: Invitee ID list.
     * - channelId: The unique identifier of the call channel. It is recommended to create via {@link createChannelId}. This property is highly recommended for preservation.
     * - rtcToken: The token obtained through the `appserver` request using `channelId`.
     * - extension: any.
     * - onResult: Returns `callId` on success, `error` on failure. The `callId` property is highly recommended for preservation.
     */
    startMultiVideoCall(params: {
        inviteeIds: string[];
        channelId: string;
        extension?: any;
        onResult: (params: {
            callId?: string;
            error?: CallError;
        }) => void;
    }): void;
    startMultiAudioCall(params: {
        inviteeIds: string[];
        channelId: string;
        extension?: any;
        onResult: (params: {
            callId?: string;
            error?: CallError;
        }) => void;
    }): void;
    /**
     * Hung up the current call.
     *
     * You can hang up the call during the call, or the inviter initiates the invitation and has not been answered.
     *
     * @params params
     * - callId: The ID obtained by {@link CallViewListener.onCallReceived}.
     * - onResult: Returns `callId` on success, `error` on failure.
     */
    hangUpCall(params: {
        callId: string;
        onResult: (params: {
            callId?: string;
            error?: CallError;
        }) => void;
    }): void;
    /**
     * Cancel the current call.
     *
     * Can only be used by the inviter.
     *
     * Only used if the invitee does not answer or declines.
     *
     * @params params
     * - callId: The ID obtained by {@link startSingleAudioCall} {@link startSingleVideoCall} {@link startMultiCall}.
     * - onResult: Returns `callId` on success, `error` on failure.
     */
    cancelCall(params: {
        callId: string;
        onResult: (params: {
            callId?: string;
            error?: CallError;
        }) => void;
    }): void;
    /**
     * decline the current call. Can only be used by the invitee.
     *
     * @params params
     * - callId: The ID obtained by {@link CallViewListener.onCallReceived}.
     * - onResult: Returns `callId` on success, `error` on failure.
     */
    refuseCall(params: {
        callId: string;
        extension?: any;
        onResult: (params: {
            callId?: string;
            error?: CallError;
        }) => void;
    }): void;
    /**
     * Accept the current call. Can only be used by the invitee.
     *
     * @params params
     * - callId: The ID obtained by {@link CallViewListener.onCallReceived}.
     * - onResult: Returns `callId` on success, `error` on failure.
     */
    acceptCall(params: {
        callId: string;
        extension?: any;
        onResult: (params: {
            callId?: string;
            error?: CallError;
        }) => void;
    }): void;
    /**
     * Whether to turn off the call audio.
     *
     * @param isMute true or false.
     */
    setAudioMute(isMute: boolean): void;
    /**
     * Whether to turn off the call video.
     *
     * @param isMute true or false.
     */
    setVideoMute(isMute: boolean): void;
    /**
     * Whether to turn off the call speak.
     *
     * @param isMute true or false.
     */
    setSpeakMute(isMute: boolean): void;
    /**
     * Get user information.
     *
     * @param userId The use ID.
     */
    getUserInfo(userId: string): CallUser | undefined;
    /**
     * Video calls are converted to voice calls.
     *
     * @params params
     * - callId: The call ID.
     * - onResult: Returns `callId` on success, `error` on failure.
     */
    videoToAudio(params: {
        callId: string;
        onResult: (params: {
            callId?: string;
            error?: CallError;
        }) => void;
    }): void;
    /**
     * Set the user information of the call.
     *
     * @param user: The user information.
     */
    setUsers(user: CallUser): void;
    /**
     * Set agora information for the current user.
     *
     * @params params
     * - channelId: The unique identifier of the call channel. It is recommended to create via {@link createChannelId}. This property is highly recommended for preservation.
     * - userId: The current user ID.
     * - userChannelId: The channel ID of user.
     * - userRTCToken: The channel token of user.
     */
    setRTCToken(params: {
        channelId: string;
        userId: string;
        userChannelId: number;
        userRTCToken: string;
    }): void;
    private _clear;
    private _clearShip;
    private _isBusy;
    private _changeState;
    private _cancelCall;
    private _hangUpCall;
    private _createInviterCall;
    private _createInviteeCall;
    private _getCall;
    private _removeCall;
    private _clearCall;
    private _getCallByChannelId;
    private _addInvitee;
    private _removeInvitee;
    private _startCall;
    private _inviteTimeout;
    private _alertTimeout;
    private _answerTimeout;
    protected _onRemoveRemoteUser(params: {
        channelId: string;
        userChannelId?: number;
        userId: string;
        reason?: CallEndReason;
    }): void;
    protected _onCallEnded(params: {
        channelId: string;
        callType: CallType;
        endReason: CallEndReason;
    }): void;
    protected _onCallOccurError(params: {
        channelId: string;
        error: CallError;
    }): void;
    protected _onSignallingMessage(msg?: ChatMessage): void;
    protected _onRequestJoin(params: {
        callId: string;
    }): void;
    private _setUser;
    private _clearUser;
    onInviteTimeout(params: {
        callId: string;
        userId: string;
    }): void;
    onAlertTimeout(params: {
        callId: string;
        userId: string;
    }): void;
    onConfirmTimeout(params: {
        callId: string;
        userId: string;
    }): void;
    onAnswerTimeout(params: {
        callId: string;
        userId: string;
    }): void;
    onInvite(params: {
        callId: string;
        callType: CallType;
        inviterId: string;
        inviterDeviceToken: string;
        channelId: string;
        ts: number;
        ext?: any;
    }): void;
    onAlert(params: {
        callId: string;
        callType?: CallType;
        inviteeId: string;
        inviterDeviceToken: string;
        inviteeDeviceToken: string;
        channelId: string;
        ts: number;
    }): void;
    onAlertConfirm(params: {
        callId: string;
        callType?: CallType;
        isValid: boolean;
        inviterId: string;
        inviterDeviceToken: string;
        inviteeDeviceToken: string;
        channelId: string;
        ts: number;
    }): void;
    onInviteCancel(params: {
        callId: string;
        callType?: CallType;
        inviterId: string;
        inviterDeviceToken: string;
        channelId: string;
        ts: number;
    }): void;
    onInviteReply(params: {
        callId: string;
        callType?: CallType;
        inviteeId: string;
        reply: typeof K.KeyBusyResult | typeof K.KeyAcceptResult | typeof K.KeyRefuseResult;
        inviteeDeviceToken: string;
        inviterDeviceToken: string;
        channelId: string;
        ts: number;
    }): void;
    onInviteReplyConfirm(params: {
        callId: string;
        callType?: CallType;
        inviterId: string;
        reply: typeof K.KeyBusyResult | typeof K.KeyAcceptResult | typeof K.KeyRefuseResult;
        inviterDeviceToken: string;
        inviteeDeviceToken: string;
        channelId: string;
        ts: number;
    }): void;
    onVideoToAudio(): void;
    joinChannel(params: {
        userRTCToken: string;
        userChannelId: number;
        channelId: string;
    }): void;
    leaveChannel(): void;
    enableVideo(): void;
    disableVideo(): void;
    enableAudio(): void;
    disableAudio(): void;
    enableAudioVolumeIndication(): void;
    startPreview(): void;
    stopPreview(): void;
    switchCamera(): void;
    enableLocalVideo(enabled: boolean): void;
    muteLocalVideoStream(mute: boolean): void;
    muteRemoteVideoStream(params: {
        userChannelId: number;
        mute: boolean;
    }): void;
    muteAllRemoteVideoStreams(mute: boolean): void;
    enableLocalAudio(enabled: boolean): void;
    muteLocalAudioStream(mute: boolean): void;
    muteRemoteAudioStream(params: {
        userChannelId: number;
        mute: boolean;
    }): void;
    muteAllRemoteAudioStreams(mute: boolean): void;
    setEnableSpeakerphone(speakerOn: boolean): void;
    onError(err: ErrorCodeType, msg: string): void;
    onJoinChannelSuccess(connection: RtcConnection, elapsed: number): void;
    onLeaveChannel(connection: RtcConnection, stats: RtcStats): void;
    onUserJoined(connection: RtcConnection, remoteUid: number, elapsed: number): void;
    onUserOffline(connection: RtcConnection, remoteUid: number, reason: UserOfflineReasonType): void;
    onVideoDeviceStateChanged(deviceId: string, deviceType: number, deviceState: number): void;
    onLocalVideoStateChanged(source: VideoSourceType, state: LocalVideoStreamState, reason: LocalVideoStreamReason): void;
    onLocalAudioStateChanged(connection: RtcConnection, state: LocalAudioStreamState, reason: LocalAudioStreamReason): void;
    onRemoteAudioStats(connection: RtcConnection, stats: RemoteAudioStats): void;
    onTokenPrivilegeWillExpire(connection: RtcConnection, token: string): void;
    onRequestToken(connection: RtcConnection): void;
    onUserMuteVideo(connection: RtcConnection, remoteUid: number, muted: boolean): void;
    onUserMuteAudio(connection: RtcConnection, remoteUid: number, muted: boolean): void;
    onAudioVolumeIndication?(connection: RtcConnection, speakers: AudioVolumeInfo[], speakerNumber: number, _totalVolume: number): void;
    onConnectionStateChanged(connection: RtcConnection, state: ConnectionStateType, reason: ConnectionChangedReasonType): void;
}
export declare function createManagerImpl(): CallManagerImpl;
//# sourceMappingURL=CallManagerImpl.d.ts.map