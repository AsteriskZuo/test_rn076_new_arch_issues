/**
 * Get the device token.
 */
export declare class CallDevice {
    _deviceToken: string;
    constructor();
    init(result: (deviceToken: string) => void): void;
    get deviceToken(): string;
}
//# sourceMappingURL=CallDevice.d.ts.map