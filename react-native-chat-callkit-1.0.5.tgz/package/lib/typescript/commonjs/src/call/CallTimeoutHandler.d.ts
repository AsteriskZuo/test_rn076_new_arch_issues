export type CallTimeoutState = 'invite' | 'alert' | 'confirm' | 'answer';
/**
 * The event listening interface of the timeout handler.
 */
export interface CallTimeoutListener {
    /**
     * Invitation message response timeout notification.
     */
    onInviteTimeout(params: {
        callId: string;
        userId: string;
    }): void;
    /**
     * alert message response timeout notification.
     */
    onAlertTimeout(params: {
        callId: string;
        userId: string;
    }): void;
    /**
     * confirm message response timeout notification.
     */
    onConfirmTimeout(params: {
        callId: string;
        userId: string;
    }): void;
    /**
     * answer message response timeout notification.
     */
    onAnswerTimeout(params: {
        callId: string;
        userId: string;
    }): void;
}
/**
 * Call timeout handler.
 */
export declare class CallTimeoutHandler {
    private _listener?;
    private _timer;
    private _timeout;
    constructor();
    init(params: {
        listener: CallTimeoutListener;
        timeout: number;
    }): void;
    unInit(): void;
    protected key(params: {
        callId: string;
        userId: string;
    }): string;
    /**
     * After the inviter message is sent, the timer starts.
     *
     * @params params
     * - callId: call id.
     * - userId: Could be an inviter or an invitee.
     * - callTimeoutState: call state.
     */
    startInviteTiming(params: {
        callId: string;
        userId: string;
    }): void;
    /**
     * After the invitee sends an alert message, the timer starts.
     */
    startAlertTiming(params: {
        callId: string;
        userId: string;
    }): void;
    /**
     * After the inviter sends a confirmation message, the timer will start.
     */
    startConfirmTiming(params: {
        callId: string;
        userId: string;
    }): void;
    /**
     * After the invitee sends a answer message, the timer will start.
     */
    startAnswerTiming(params: {
        callId: string;
        userId: string;
    }): void;
    /**
     * Manually stop the timeout without triggering the callback notification.
     *
     * @params params
     * - callId: call id.
     * - userId: Could be an inviter or an invitee.
     */
    stopTiming(params: {
        callId: string;
        userId: string;
    }): void;
    /**
     * Stop all timers and destroy.
     */
    clear(): void;
    /**
     * After the xxx message is sent, the timer starts.
     *
     * @params params
     * - callId: call id.
     * - userId: Could be an inviter or an invitee.
     * - callTimeoutState: call timeout state.
     */
    startTiming(params: {
        callId: string;
        userId: string;
        callTimeoutState: CallTimeoutState;
    }): void;
    hasTiming(params: {
        callId: string;
        userId: string;
    }): boolean;
}
//# sourceMappingURL=CallTimeoutHandler.d.ts.map