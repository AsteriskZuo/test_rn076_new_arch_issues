declare const VERSION = "1.0.5";
export default VERSION;
//# sourceMappingURL=version.d.ts.map