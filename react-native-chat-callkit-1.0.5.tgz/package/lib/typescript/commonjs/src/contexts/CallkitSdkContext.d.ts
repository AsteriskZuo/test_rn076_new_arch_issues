import React from 'react';
import type { CallManager } from '../call';
type CallkitSdkContextProps = React.PropsWithChildren<{
    call: CallManager;
}>;
export declare function CallkitSdkContextProvider({ call, children, }: CallkitSdkContextProps): import("react/jsx-runtime").JSX.Element;
export declare function useCallkitSdkContext(): CallkitSdkContextProps;
export {};
//# sourceMappingURL=CallkitSdkContext.d.ts.map