export * from 'react-native-chat-sdk';
//# sourceMappingURL=rename.chat.d.ts.map